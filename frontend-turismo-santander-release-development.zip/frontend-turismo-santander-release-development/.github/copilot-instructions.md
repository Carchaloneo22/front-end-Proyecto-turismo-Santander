Los mensajes de commit deben escribirse en español.
Usar verbos en infinitivo al inicio del mensaje (ej: "Agregar", "Corregir", "Eliminar", "Refactorizar").
