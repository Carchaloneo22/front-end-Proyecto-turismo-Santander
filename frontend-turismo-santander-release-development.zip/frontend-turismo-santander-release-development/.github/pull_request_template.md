## Descripción

<!-- Breve descripción de qué hace este PR -->

## Tipo de cambio

- [ ] feat: nueva funcionalidad
- [ ] fix: corrección de bug
- [ ] refactor: refactorización sin cambio funcional
- [ ] style: cambios de formato/estilo
- [ ] docs: documentación
- [ ] ci: cambios en CI/CD
- [ ] test: agregar/modificar tests

## Checklist

- [ ] Mi código sigue las convenciones del proyecto
- [ ] He ejecutado `npm run lint` sin errores
- [ ] He ejecutado `npm run test` sin errores
- [ ] He agregado tests para los cambios (si aplica)
- [ ] La build `npm run build` pasa correctamente

## Screenshots (si aplica)

<!-- Capturas de pantalla del cambio visual -->

## Notas adicionales

<!-- Contexto extra para los revisores -->
