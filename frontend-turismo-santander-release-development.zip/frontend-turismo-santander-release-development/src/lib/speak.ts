/** Lee un texto en voz alta (Web Speech API). Cancela lo anterior para no encimar. */
export function speak(text: string, lang = 'es-CO') {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return
  const synth = window.speechSynthesis
  synth.cancel()
  const u = new SpeechSynthesisUtterance(text)
  u.lang = lang
  synth.speak(u)
}
export function stopSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.cancel()
}
