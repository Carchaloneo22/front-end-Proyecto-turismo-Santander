import { localStore } from '../services/storage/StorageService'

/**
 * Sesión DEMO para la presentación. NO es autenticación real: guarda un usuario
 * en localStorage para que el flujo login/registro → dashboard funcione en la
 * demo mientras el backend de auth no está conectado. Reemplazar por la sesión
 * real (cookie httpOnly + `useAuthStore`) cuando se integre el backend.
 */
export interface SesionDemo {
  nombre: string
  email: string
}

const CLAVE = 'sesionDemo'

export function guardarSesion(s: SesionDemo): void {
  localStore.set(CLAVE, s)
}

export function leerSesion(): SesionDemo | null {
  return localStore.get<SesionDemo>(CLAVE, null)
}

export function cerrarSesion(): void {
  localStore.remove(CLAVE)
}
