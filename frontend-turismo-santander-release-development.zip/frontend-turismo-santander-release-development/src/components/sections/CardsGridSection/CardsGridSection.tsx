import { Container } from '../../ui/Container'
import { SectionHeader } from '../../ui/SectionHeader'
import { Card } from '../../ui/Card'
import type { CardProps } from '../../ui/Card'
import styles from './CardsGridSection.module.css'

interface CardsGridSectionProps {
  title: string
  subtitle?: string
  items: CardProps[]
  headerAlign?: 'left' | 'center'
  loading?: boolean
  /** Mensaje de fallo. Si viene, manda sobre `loading` y sobre la rejilla. */
  error?: string | null
  /** Qué se dice mientras carga y cuando no hay nada. La sección la usan varias
   *  páginas, así que el dominio lo pone quien la llama, no ella. */
  loadingLabel?: string
  emptyLabel?: string
}

export function CardsGridSection({
  title,
  subtitle,
  items,
  headerAlign = 'left',
  loading = false,
  error = null,
  loadingLabel = 'Cargando…',
  emptyLabel = 'No hay resultados disponibles.',
}: CardsGridSectionProps) {
  return (
    <section className={styles.section}>
      <Container maxWidth={1300}>
        <SectionHeader title={title} subtitle={subtitle} align={headerAlign} />
        {error ? (
          // role="alert" para que un lector de pantalla lo anuncie al aparecer:
          // un fallo silencioso es indistinguible de una lista vacía.
          <p className={styles.estado} role="alert">
            {error}
          </p>
        ) : loading ? (
          <p className={styles.estado} role="status">
            {loadingLabel}
          </p>
        ) : items.length === 0 ? (
          <p className={styles.estado}>{emptyLabel}</p>
        ) : (
          <div className={styles.grid}>
            {items.map((item, i) => (
              <Card key={`${item.title}-${i}`} {...item} />
            ))}
          </div>
        )}
      </Container>
    </section>
  )
}
