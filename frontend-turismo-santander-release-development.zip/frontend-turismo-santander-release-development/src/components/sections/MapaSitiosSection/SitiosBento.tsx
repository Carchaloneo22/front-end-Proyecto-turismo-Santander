import { useEffect, useRef, useState } from 'react'
import { CATEGORIAS, type SitioConDestino } from '../../../features/destinos'
import { useReducedMotion } from '../../../hooks/useReducedMotion'
import styles from './MapaSitiosSection.module.css'

interface SitiosBentoProps {
  items: SitioConDestino[]
  onSelect: (item: SitioConDestino) => void
}

const CELDAS = 5 // 1 grande + 4 pequeñas (layout bento)
const CADA_MS = 2600 // cada cuánto rota UNA celda
const FADE_MS = 450 // duración del desvanecido (igual que la transición CSS)

/**
 * SitiosBento — cuadrícula tipo "bento" con varias tarjetas a la vez. Las celdas
 * NO se deslizan: cada una flota suavemente en su lugar y, por turnos, se
 * desvanece para dar paso a otro sitio (crossfade). Sin controles de usuario.
 *
 * Rotación con estado React + transiciones CSS (sin GSAP: nada que pueda fallar).
 * Se pausa al pasar el mouse/enfocar (para poder hacer clic → abre el modal).
 * Con `prefers-reduced-motion`: sin flotado y sin rotación automática.
 */
export function SitiosBento({ items, onSelect }: SitiosBentoProps) {
  const reduce = useReducedMotion()
  // Qué sitio (índice en items) muestra cada celda.
  const [slots, setSlots] = useState<number[]>(() => Array.from({ length: CELDAS }, (_, i) => i))
  const [fadingCell, setFadingCell] = useState<number | null>(null)
  const pausedRef = useRef(false)
  const nextRef = useRef(CELDAS) // siguiente sitio a entrar
  const cellRef = useRef(0) // celda a la que le toca rotar

  // Reinicia los slots si cambia la cantidad de items (filtros).
  useEffect(() => {
    queueMicrotask(() => {
      setSlots(Array.from({ length: CELDAS }, (_, i) => i % Math.max(items.length, 1)))
      nextRef.current = CELDAS % Math.max(items.length, 1)
    })
  }, [items.length])

  // Rotación por turnos: una celda se desvanece, cambia de sitio y reaparece.
  useEffect(() => {
    if (reduce || items.length <= CELDAS) return
    const id = setInterval(() => {
      if (pausedRef.current) return
      const celda = cellRef.current % CELDAS
      cellRef.current += 1
      setFadingCell(celda)
      setTimeout(() => {
        setSlots((prev) => {
          const next = [...prev]
          // Evita mostrar un sitio que ya está visible en otra celda.
          let candidato = nextRef.current % items.length
          for (let salto = 0; salto < items.length && next.includes(candidato); salto++) {
            candidato = (candidato + 1) % items.length
          }
          nextRef.current = (candidato + 1) % items.length
          next[celda] = candidato
          return next
        })
        setFadingCell(null)
      }, FADE_MS)
    }, CADA_MS)
    return () => clearInterval(id)
  }, [items.length, reduce])

  if (!items.length) return null

  return (
    <div
      className={styles.bento}
      role="group"
      aria-label="Sitios turísticos destacados (rotación automática)"
      onMouseEnter={() => (pausedRef.current = true)}
      onMouseLeave={() => (pausedRef.current = false)}
      onFocusCapture={() => (pausedRef.current = true)}
      onBlurCapture={() => (pausedRef.current = false)}
    >
      {slots.map((itemIdx, celda) => {
        const item = items[itemIdx % items.length]
        if (!item) return null
        const cat = CATEGORIAS[item.sitio.categoria]
        const grande = celda === 0
        return (
          <div
            key={celda}
            className={[
              styles.bentoCell,
              grande ? styles.bentoBig : '',
              fadingCell === celda ? styles.bentoFading : '',
            ]
              .filter(Boolean)
              .join(' ')}
          >
            <button
              type="button"
              className={styles.bentoButton}
              onClick={() => onSelect(item)}
              aria-label={`${item.sitio.nombre}. ${cat.label}. ${item.destino.nombre}. Ver detalle y 360°.`}
            >
              <img
                src={item.sitio.imagen}
                alt=""
                className={styles.bentoImg}
                loading="lazy"
                draggable={false}
              />
              <span className={styles.bentoOverlay} aria-hidden="true" />
              <span className={styles.bentoCat} style={{ background: cat.color }}>
                <span aria-hidden="true">{cat.emoji}</span> {cat.label}
              </span>
              <span className={styles.bentoInfo}>
                <span className={styles.bentoName}>{item.sitio.nombre}</span>
                <span className={styles.bentoMuni}>📍 {item.destino.nombre}</span>
              </span>
            </button>
          </div>
        )
      })}
    </div>
  )
}
