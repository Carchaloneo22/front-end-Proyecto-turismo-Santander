import { useId, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Modal } from '../../ui/Modal'
import { Heading } from '../../ui/Heading'
import { Text } from '../../ui/Text'
import { Button } from '../../ui/Button'
import { Badge } from '../../ui/Badge'
import { CATEGORIAS, type SitioConDestino } from '../../../features/destinos'
import styles from './MapaSitiosSection.module.css'

interface SitioModalProps {
  /** Sitio seleccionado + su municipio, o null si el modal está cerrado. */
  seleccion: SitioConDestino | null
  onClose: () => void
}

/**
 * SitioModal — detalle de un sitio: galería de imágenes, info y botón "Ver en 3D"
 * que abre el metaverso 360° del sitio. Reutiliza el átomo Modal (accesibilidad)
 * y delega la navegación (SRP).
 */
export function SitioModal({ seleccion, onClose }: SitioModalProps) {
  const navigate = useNavigate()
  const titleId = useId()
  const [imgActiva, setImgActiva] = useState(0)

  if (!seleccion) return null
  const { sitio, destino } = seleccion
  const cat = CATEGORIAS[sitio.categoria]
  const imagenes = sitio.imagenes.length ? sitio.imagenes : [sitio.imagen]
  const principal = imagenes[Math.min(imgActiva, imagenes.length - 1)]

  const verEn3D = () => {
    onClose()
    navigate(`/metaverso/${destino.slug}?sitio=${sitio.id}`)
  }

  return (
    <Modal isOpen onClose={onClose} titleId={titleId} className={styles.modal}>
      <div className={styles.gallery}>
        <img src={principal} alt={sitio.imagenAlt} className={styles.galleryMain} />
        <Badge className={styles.modalBadge} style={{ background: cat.color }}>
          <span aria-hidden="true">{cat.emoji}</span> {cat.label}
        </Badge>
      </div>

      {imagenes.length > 1 && (
        <div className={styles.thumbs} role="group" aria-label="Galería de imágenes">
          {imagenes.map((src, i) => (
            <button
              key={src}
              type="button"
              className={`${styles.thumb} ${i === imgActiva ? styles.thumbActive : ''}`}
              aria-label={`Ver imagen ${i + 1} de ${imagenes.length}`}
              aria-pressed={i === imgActiva}
              onClick={() => setImgActiva(i)}
            >
              <img src={src} alt="" />
            </button>
          ))}
        </div>
      )}

      <div className={styles.modalBody}>
        <Heading level={2} size={3} id={titleId}>
          {sitio.nombre}
        </Heading>
        <Text size="sm" muted className={styles.modalLoc}>
          📍 {destino.nombre}
        </Text>
        <Text>{sitio.descripcion}</Text>

        <div className={styles.modalActions}>
          <Button
            onClick={verEn3D}
            aria-label={`Ver ${sitio.nombre} en el metaverso 360°`}
            iconLeft={<span aria-hidden="true">🥽</span>}
          >
            Ver en 3D
          </Button>
          <Text as="span" size="xs" muted>
            {sitio.coordenada.lat.toFixed(4)}°N, {Math.abs(sitio.coordenada.lng).toFixed(4)}°O
          </Text>
        </div>
      </div>
    </Modal>
  )
}
