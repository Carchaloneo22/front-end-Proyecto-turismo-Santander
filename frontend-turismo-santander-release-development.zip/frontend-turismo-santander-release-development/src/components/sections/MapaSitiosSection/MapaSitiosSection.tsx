import { useEffect, useMemo, useRef, useState } from 'react'
import maplibregl, {
  type StyleSpecification,
  type FilterSpecification,
  type MapGeoJSONFeature,
} from 'maplibre-gl'
import type { FeatureCollection, Point } from 'geojson'
import 'maplibre-gl/dist/maplibre-gl.css'
import { Container } from '../../ui/Container'
import { SectionHeader } from '../../ui/SectionHeader'
import { SitioModal } from './SitioModal'
import { SitiosBento } from './SitiosBento'
import {
  CATEGORIAS,
  CATEGORIA_KEYS,
  type CategoriaSitio,
  type SitioConDestino,
} from '../../../features/destinos'
import { useConsentStore } from '../../../store/consent.store'
import styles from './MapaSitiosSection.module.css'

interface MapaSitiosSectionProps {
  sitios: SitioConDestino[]
  title?: string
  subtitle?: string
}

const AMB_CENTER: [number, number] = [-73.115, 7.095]
const SOURCE_ID = 'sitios'
const LAYER_ID = 'sitios-circles'
const GLOW_ID = 'sitios-glow'

// Estilo del mapa: satélite ESRI + etiquetas oscuras CARTO (rasters sin API key).
const MAP_STYLE: StyleSpecification = {
  version: 8,
  sources: {
    'esri-satellite': {
      type: 'raster',
      tiles: [
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      ],
      tileSize: 256,
      attribution: 'Tiles © Esri',
      maxzoom: 19,
    },
    'carto-labels': {
      type: 'raster',
      tiles: [
        'https://a.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}@2x.png',
        'https://b.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}@2x.png',
      ],
      tileSize: 256,
      maxzoom: 19,
    },
  },
  layers: [
    { id: 'satellite', type: 'raster', source: 'esri-satellite' },
    { id: 'labels', type: 'raster', source: 'carto-labels' },
  ],
}

// Radio del círculo según zoom (crece un poco al hacer hover con feature-state).
const RADIUS = [
  'interpolate',
  ['linear'],
  ['zoom'],
  10,
  ['case', ['boolean', ['feature-state', 'hover'], false], 8, 5],
  13,
  ['case', ['boolean', ['feature-state', 'hover'], false], 11, 7],
  16,
  ['case', ['boolean', ['feature-state', 'hover'], false], 15, 10],
]

/**
 * MapaSitiosSection — mapa interactivo del departamento. Los sitios se dibujan
 * como una CAPA de círculos GeoJSON: MapLibre los renderiza como parte del mapa
 * (en la GPU, ancladas a lng/lat), así que quedan FIJOS al terreno y no se
 * desplazan ni se retrasan con el zoom o el paneo. Al hacer clic → modal con
 * info, galería y "Ver en 3D".
 *
 * Accesibilidad: como los círculos van en el canvas (no son focusables), se
 * ofrece una lista `<details>` con un botón por sitio que abre el mismo modal,
 * operable por teclado y lectores de pantalla. Filtros con `aria-pressed`.
 */
export function MapaSitiosSection({
  sitios,
  title = 'Sitios turísticos de Santander',
  subtitle = 'Explora el mapa del Área Metropolitana. Toca un punto para ver el lugar y abrirlo en 360°.',
}: MapaSitiosSectionProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<maplibregl.Map | null>(null)
  const hoveredRef = useRef<number | null>(null)

  // Consentimiento de "mapas": las teselas vienen de terceros (Esri/Carto), así
  // que NO se inicializa el mapa hasta que el titular lo acepta.
  const mapasOK = useConsentStore((s) => s.mapas)
  const activarCategoria = useConsentStore((s) => s.activarCategoria)

  const [ready, setReady] = useState(false)
  const [seleccion, setSeleccion] = useState<SitioConDestino | null>(null)
  const [activeCats, setActiveCats] = useState<Set<CategoriaSitio>>(new Set(CATEGORIA_KEYS))
  const [activeMunicipio, setActiveMunicipio] = useState<string>('todos')

  // Índice numérico → sitio, para resolver clics/hover de la capa.
  const index = useMemo(() => new Map(sitios.map((s, i) => [i, s] as const)), [sitios])

  // GeoJSON con id numérico (necesario para feature-state) + color por categoría.
  const geojson = useMemo<FeatureCollection<Point>>(
    () => ({
      type: 'FeatureCollection',
      features: sitios.map((s, i) => ({
        type: 'Feature',
        id: i,
        geometry: { type: 'Point', coordinates: [s.sitio.coordenada.lng, s.sitio.coordenada.lat] },
        properties: {
          categoria: s.sitio.categoria,
          color: CATEGORIAS[s.sitio.categoria].color,
          destinoSlug: s.destino.slug,
        },
      })),
    }),
    [sitios],
  )

  const municipios = useMemo(() => {
    const m = new Map<string, string>()
    sitios.forEach(({ destino }) => m.set(destino.slug, destino.nombre))
    return Array.from(m, ([slug, nombre]) => ({ slug, nombre }))
  }, [sitios])

  const visibles = useMemo(
    () =>
      sitios.filter(
        ({ sitio, destino }) =>
          activeCats.has(sitio.categoria) &&
          (activeMunicipio === 'todos' || destino.slug === activeMunicipio),
      ),
    [sitios, activeCats, activeMunicipio],
  )

  // ── Init del mapa + capa GeoJSON ──
  useEffect(() => {
    // Sin consentimiento de "mapas" no se carga NADA de terceros.
    if (!containerRef.current || !mapasOK) return
    const map = new maplibregl.Map({
      container: containerRef.current,
      style: MAP_STYLE,
      center: AMB_CENTER,
      zoom: 11,
      minZoom: 9,
      maxZoom: 18,
      // Vista 3D inclinada. SOLO pitch/bearing: sin terreno DEM (sin CORS) y sin
      // setSky — esas dos piezas fueron las que dejaban el mapa en blanco.
      // maxPitch 60 evita que aparezca el "hueco" del horizonte sobre el satélite.
      pitch: 45,
      bearing: -17,
      maxPitch: 60,
      attributionControl: false,
    })
    mapRef.current = map
    // Brújula con visualización de inclinación → rotar/enderezar la vista.
    map.addControl(
      new maplibregl.NavigationControl({ showCompass: true, visualizePitch: true }),
      'top-right',
    )

    // Diagnóstico: si un tile o el estilo fallan, lo vemos en la consola.
    map.on('error', (e) => {
      console.error('[MapaSitios] error del mapa:', e.error ?? e)
    })

    map.on('load', () => {
      map.addSource(SOURCE_ID, { type: 'geojson', data: geojson })

      // Halo suave (glow) detrás del punto.
      map.addLayer({
        id: GLOW_ID,
        type: 'circle',
        source: SOURCE_ID,
        paint: {
          'circle-radius': RADIUS as never,
          'circle-color': ['get', 'color'] as never,
          'circle-opacity': 0.25,
          'circle-blur': 1,
        },
      })

      // Punto principal (fijo al terreno).
      map.addLayer({
        id: LAYER_ID,
        type: 'circle',
        source: SOURCE_ID,
        paint: {
          'circle-radius': RADIUS as never,
          'circle-color': ['get', 'color'] as never,
          'circle-stroke-width': 2,
          'circle-stroke-color': '#ffffff',
          'circle-opacity': 0.96,
        },
      })

      // Interacciones
      map.on('click', LAYER_ID, (e) => {
        const f = e.features?.[0] as MapGeoJSONFeature | undefined
        if (f == null || f.id == null) return
        const item = index.get(f.id as number)
        if (item) setSeleccion(item)
      })
      map.on('mouseenter', LAYER_ID, () => {
        map.getCanvas().style.cursor = 'pointer'
      })
      map.on('mousemove', LAYER_ID, (e) => {
        const f = e.features?.[0]
        if (f == null || f.id == null) return
        if (hoveredRef.current !== null) {
          map.setFeatureState({ source: SOURCE_ID, id: hoveredRef.current }, { hover: false })
        }
        hoveredRef.current = f.id as number
        map.setFeatureState({ source: SOURCE_ID, id: hoveredRef.current }, { hover: true })
      })
      map.on('mouseleave', LAYER_ID, () => {
        if (hoveredRef.current !== null) {
          map.setFeatureState({ source: SOURCE_ID, id: hoveredRef.current }, { hover: false })
        }
        hoveredRef.current = null
        map.getCanvas().style.cursor = ''
      })

      setReady(true)
    })

    return () => {
      map.remove()
      mapRef.current = null
      hoveredRef.current = null
      setReady(false)
    }
  }, [geojson, index, mapasOK])

  // ── Filtros (categoría + municipio) → setFilter sobre las capas ──
  useEffect(() => {
    const map = mapRef.current
    if (!map || !ready) return
    const filter: FilterSpecification = (
      activeMunicipio === 'todos'
        ? ['all', ['in', ['get', 'categoria'], ['literal', Array.from(activeCats)]]]
        : [
            'all',
            ['in', ['get', 'categoria'], ['literal', Array.from(activeCats)]],
            ['==', ['get', 'destinoSlug'], activeMunicipio],
          ]
    ) as FilterSpecification
    map.setFilter(LAYER_ID, filter)
    map.setFilter(GLOW_ID, filter)
  }, [activeCats, activeMunicipio, ready])

  // ── Fly-to al cambiar de municipio ──
  useEffect(() => {
    const map = mapRef.current
    if (!map || !ready) return
    const pts =
      activeMunicipio === 'todos'
        ? sitios
        : sitios.filter(({ destino }) => destino.slug === activeMunicipio)
    if (!pts.length) return
    const bounds = new maplibregl.LngLatBounds()
    pts.forEach(({ sitio }) => bounds.extend([sitio.coordenada.lng, sitio.coordenada.lat]))
    map.fitBounds(bounds, {
      padding: 90,
      duration: 1400,
      maxZoom: activeMunicipio === 'todos' ? 12.5 : 13.5,
      pitch: 45, // conserva la vista 3D inclinada
      bearing: -17,
    })
  }, [activeMunicipio, ready, sitios])

  const toggleCat = (c: CategoriaSitio) =>
    setActiveCats((prev) => {
      const next = new Set(prev)
      if (next.has(c)) next.delete(c)
      else next.add(c)
      return next
    })

  return (
    <section className={styles.section} aria-label={title}>
      <Container maxWidth={1400}>
        <SectionHeader title={title} subtitle={subtitle} align="center" />

        <div className={styles.municipios} role="group" aria-label="Filtrar por municipio">
          <button
            type="button"
            className={`${styles.chip} ${activeMunicipio === 'todos' ? styles.chipActive : ''}`}
            aria-pressed={activeMunicipio === 'todos'}
            onClick={() => setActiveMunicipio('todos')}
          >
            Área Metropolitana
          </button>
          {municipios.map((m) => (
            <button
              key={m.slug}
              type="button"
              className={`${styles.chip} ${activeMunicipio === m.slug ? styles.chipActive : ''}`}
              aria-pressed={activeMunicipio === m.slug}
              onClick={() => setActiveMunicipio(m.slug)}
            >
              {m.nombre}
            </button>
          ))}
        </div>

        <div className={styles.mapWrap}>
          {mapasOK ? (
            <div
              ref={containerRef}
              className={styles.map}
              role="application"
              aria-label={`Mapa con ${visibles.length} sitios turísticos. La lista de abajo permite abrir cada sitio con el teclado.`}
            />
          ) : (
            <div className={styles.map} data-consent-placeholder>
              <div className={styles.consentBox} role="note">
                <p>
                  El mapa interactivo carga imágenes desde proveedores externos (Esri y Carto), que
                  reciben tu dirección IP. Actívalo para verlo; también puedes explorar todos los
                  sitios en la lista de abajo, sin cargar terceros.
                </p>
                <button
                  type="button"
                  className={styles.consentBtn}
                  onClick={() => activarCategoria('mapas')}
                >
                  Activar el mapa
                </button>
              </div>
            </div>
          )}

          <div className={styles.legend} role="group" aria-label="Filtrar por categoría">
            <h4 className={styles.legendTitle}>Categorías</h4>
            {CATEGORIA_KEYS.map((c) => {
              const on = activeCats.has(c)
              return (
                <button
                  key={c}
                  type="button"
                  className={`${styles.legendItem} ${on ? '' : styles.legendOff}`}
                  aria-pressed={on}
                  onClick={() => toggleCat(c)}
                >
                  <span className={styles.legendDot} style={{ background: CATEGORIAS[c].color }} />
                  {CATEGORIAS[c].label}
                </button>
              )
            })}
          </div>
        </div>

        <p className={styles.counter} aria-live="polite">
          Mostrando <strong>{visibles.length}</strong> de {sitios.length} sitios
        </p>
      </Container>

      {/* Bento de sitios: tarjetas fijas que rotan por desvanecido (vía accesible). */}
      <Container maxWidth={1400}>
        <SitiosBento items={visibles} onSelect={setSeleccion} />
      </Container>

      <SitioModal seleccion={seleccion} onClose={() => setSeleccion(null)} />
    </section>
  )
}
