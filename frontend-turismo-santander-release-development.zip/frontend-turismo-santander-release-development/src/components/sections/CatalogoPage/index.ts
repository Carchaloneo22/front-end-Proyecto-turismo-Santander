export { CatalogoPage, type CatalogoPageProps } from './CatalogoPage'
