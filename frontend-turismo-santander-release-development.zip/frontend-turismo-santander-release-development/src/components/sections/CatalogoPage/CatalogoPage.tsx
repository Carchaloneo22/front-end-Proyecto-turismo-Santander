import { useMemo } from 'react'
import { Hero } from '../Hero/Hero'
import { CardsGridSection } from '../CardsGridSection'
import { Loader } from '../../ui/Loader'
import type { CardProps } from '../../ui/Card'
import { useSEO } from '../../../hooks/useSEO'
import { useAssetPreloader } from '../../../hooks/useAssetPreloader'
import type { Asset } from '../../../lib/preload'

/**
 * CatalogoPage — el armazón de las páginas de catálogo: planes, hospedaje,
 * transporte y artesanías.
 *
 * Las cuatro eran la MISMA página con otro servicio: hero con banner, rejilla de
 * tarjetas, y los estados de cargando/error/vacío. Estaban copiadas cuatro
 * veces, y se notó: a las cuatro les faltaba precargar el banner, así que el
 * hero enseñaba su fondo morado y la imagen entraba de golpe un segundo después.
 * Arreglarlo por separado era arreglarlo cuatro veces y olvidarse en la quinta.
 *
 * Aquí vive la parte visual y de carga; cada página aporta SUS datos y su
 * traducción a tarjetas. La página no sabe de precarga y este componente no sabe
 * de servicios.
 */
export interface CatalogoPageProps {
  seo: { title: string; description: string }
  hero: {
    eyebrow: string
    title: string
    subtitle: string
    /** Imagen de cabecera. Se precarga antes de pintar: es la que causaba el salto. */
    banner: string
  }
  grid: {
    title: string
    subtitle: string
    loadingLabel: string
    emptyLabel: string
  }
  items: CardProps[]
  cargando: boolean
  error: string | null
  /** Lo que se anuncia mientras se precarga el banner ("Cargando planes"). */
  etiquetaCarga: string
}

export function CatalogoPage({
  seo,
  hero,
  grid,
  items,
  cargando,
  error,
  etiquetaCarga,
}: CatalogoPageProps) {
  useSEO({ title: seo.title, description: seo.description })

  // Solo el banner. Las imágenes de las tarjetas NO se precargan a propósito:
  // pueden ser decenas, y bloquear la página entera por ellas cambiaría un salto
  // de un segundo por una espera de varios. Cada tarjeta carga la suya con
  // loading="lazy". El banner es distinto: ocupa la pantalla al entrar.
  const assets = useMemo<Asset[]>(() => [{ url: hero.banner, type: 'image' }], [hero.banner])
  const { ready, progress } = useAssetPreloader(assets)

  return (
    <>
      {!ready && <Loader progress={progress} label={etiquetaCarga} />}

      <Hero
        variant="page"
        eyebrow={hero.eyebrow}
        title={hero.title}
        subtitle={hero.subtitle}
        poster={hero.banner}
      />

      <CardsGridSection
        title={grid.title}
        subtitle={grid.subtitle}
        items={items}
        loading={cargando}
        error={error}
        loadingLabel={grid.loadingLabel}
        emptyLabel={grid.emptyLabel}
      />
    </>
  )
}
