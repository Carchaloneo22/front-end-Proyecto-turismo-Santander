import { useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { Link } from '../../ui/Link'
import { Heading } from '../../ui/Heading'
import { Text } from '../../ui/Text'
import { useHeroAnimation } from '../../../hooks/useHeroAnimation'
import styles from './Hero.module.css'

interface HeroProps {
  title: ReactNode
  subtitle?: string
  eyebrow?: string
  videoSrc?: string
  poster?: string
  ctaLabel?: string
  ctaTo?: string
  secondaryLabel?: string
  secondaryTo?: string
  variant?: 'home' | 'page'
}

export function Hero({
  title,
  subtitle,
  eyebrow,
  videoSrc,
  poster,
  ctaLabel,
  ctaTo,
  secondaryLabel,
  secondaryTo,
  variant = 'page',
}: HeroProps) {
  const heroRef = useRef<HTMLElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const [muted, setMuted] = useState(true)

  useHeroAnimation(heroRef) // ← GSAP encapsulado

  const toggleSound = () => {
    const v = videoRef.current
    if (!v) return
    v.muted = !v.muted
    setMuted(v.muted)
  }

  return (
    <section ref={heroRef} className={`${styles.hero} ${styles[variant]}`}>
      {videoSrc ? (
        <video
          ref={videoRef}
          data-hero-el="media"
          className={styles.media}
          poster={poster}
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          // Prioridad de descarga alta: el video del hero es lo primero que se ve.
          {...{ fetchpriority: 'high' }}
        >
          <source src={videoSrc} type="video/mp4" />
        </video>
      ) : poster ? (
        <img data-hero-el="media" className={styles.media} src={poster} alt="" />
      ) : null}

      <div className={styles.overlay} />

      <div data-hero-el="content" className={styles.content}>
        {eyebrow && (
          <span data-hero-el="eyebrow" className={styles.eyebrow}>
            {eyebrow}
          </span>
        )}
        <Heading
          data-hero-el="title"
          level={1}
          size={1}
          align="center"
          color="#fff"
          className={styles.title}
        >
          {title}
        </Heading>
        {subtitle && (
          <Text
            data-hero-el="subtitle"
            size="lg"
            align="center"
            color="rgba(255,255,255,0.92)"
            className={styles.subtitle}
          >
            {subtitle}
          </Text>
        )}
        {(ctaLabel || secondaryLabel) && (
          <div data-hero-el="actions" className={styles.actions}>
            {ctaLabel && ctaTo && (
              <Link to={ctaTo} className={styles.ctaPrimary}>
                {ctaLabel} →
              </Link>
            )}
            {secondaryLabel && secondaryTo && (
              <Link to={secondaryTo} className={styles.ctaSecondary}>
                {secondaryLabel}
              </Link>
            )}
          </div>
        )}
      </div>

      {videoSrc && (
        <button
          className={styles.sound}
          onClick={toggleSound}
          aria-label={muted ? 'Activar sonido' : 'Silenciar'}
          title={muted ? 'Activar sonido' : 'Silenciar'}
        >
          {muted ? '🔇' : '🔊'}
        </button>
      )}

      {variant === 'home' && (
        <div className={styles.scroll} aria-hidden="true">
          ↓
        </div>
      )}
    </section>
  )
}
