import { useState } from 'react'
import styles from './MapaSantander.module.css'

export interface OpcionChip {
  id: string
  label: string
  icono: string
  color?: string
}

interface GrupoChipsProps {
  titulo: string
  opciones: OpcionChip[]
  valor: string
  todosLabel: string
  onChange: (id: string) => void
  /** Cuántos chips se ven plegado / por página al desplegar. */
  visiblesPlegado?: number
  porPagina?: number
}

/**
 * Grupo de filtros compacto: muestra unos pocos chips y un botón «+» que
 * despliega el resto PAGINADO. Mantener la paginación en el cliente hoy deja el
 * camino listo para pedir las páginas al backend mañana (misma UI, otra fuente).
 */
export function GrupoChips({
  titulo,
  opciones,
  valor,
  todosLabel,
  onChange,
  visiblesPlegado = 3,
  porPagina = 6,
}: GrupoChipsProps) {
  const [abierto, setAbierto] = useState(false)
  const [pagina, setPagina] = useState(0)

  const paginas = Math.max(1, Math.ceil(opciones.length / porPagina))
  const pag = Math.min(pagina, paginas - 1)
  const visibles = abierto
    ? opciones.slice(pag * porPagina, (pag + 1) * porPagina)
    : opciones.slice(0, visiblesPlegado)
  const ocultos = opciones.length - visiblesPlegado

  return (
    <div className={styles.grupo}>
      <p className={styles.grupoTitulo}>{titulo}</p>
      <div className={styles.chips} role="group" aria-label={titulo}>
        <button
          type="button"
          className={`${styles.chip} ${valor === 'todos' ? styles.on : ''}`}
          aria-pressed={valor === 'todos'}
          onClick={() => onChange('todos')}
        >
          {todosLabel}
        </button>

        {visibles.map((o) => (
          <button
            key={o.id}
            type="button"
            className={`${styles.chip} ${valor === o.id ? styles.on : ''}`}
            style={
              valor === o.id && o.color ? { background: o.color, borderColor: o.color } : undefined
            }
            aria-pressed={valor === o.id}
            onClick={() => onChange(o.id)}
            title={o.label}
          >
            <span aria-hidden="true">{o.icono}</span> {o.label}
          </button>
        ))}

        {ocultos > 0 && (
          <button
            type="button"
            className={`${styles.chip} ${styles.mas}`}
            aria-expanded={abierto}
            onClick={() => setAbierto((a) => !a)}
          >
            {abierto ? '− menos' : `+ ${ocultos} más`}
          </button>
        )}
      </div>

      {abierto && paginas > 1 && (
        <div className={styles.pag}>
          <button
            type="button"
            className={styles.pagBtn}
            onClick={() => setPagina((p) => Math.max(0, p - 1))}
            disabled={pag === 0}
            aria-label="Página anterior de filtros"
          >
            ‹
          </button>
          <span className={styles.pagInfo}>
            {pag + 1} / {paginas}
          </span>
          <button
            type="button"
            className={styles.pagBtn}
            onClick={() => setPagina((p) => Math.min(paginas - 1, p + 1))}
            disabled={pag >= paginas - 1}
            aria-label="Página siguiente de filtros"
          >
            ›
          </button>
        </div>
      )}
    </div>
  )
}
