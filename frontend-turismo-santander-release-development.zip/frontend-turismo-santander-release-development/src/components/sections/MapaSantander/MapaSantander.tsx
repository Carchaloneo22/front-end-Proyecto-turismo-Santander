import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import maplibregl, { type StyleSpecification, type MapGeoJSONFeature } from 'maplibre-gl'
import type { FeatureCollection, Point } from 'geojson'
import 'maplibre-gl/dist/maplibre-gl.css'
import { Container } from '../../ui/Container'
import { SectionHeader } from '../../ui/SectionHeader'
import { useListado } from '../../../hooks/useListado'
import { sitiosMapaService, type SitioMapa } from '../../../services'
import {
  MODALIDADES,
  MODALIDAD_KEYS,
  type ModalidadId,
} from '../../../features/experiencias/modalidades'
import {
  TIPOS_LUGAR,
  TIPO_LUGAR_KEYS,
  type TipoLugar,
} from '../../../features/experiencias/tiposLugar'
import { useConsentStore } from '../../../store/consent.store'
import { asset } from '../../../lib/asset'
import { GrupoChips } from './GrupoChips'
import styles from './MapaSantander.module.css'

const CENTRO_SANTANDER: [number, number] = [-73.53, 6.91]
/** Extensión REAL del departamento (bbox del contorno oficial DANE). */
const SANTANDER_BOUNDS: [[number, number], [number, number]] = [
  [-74.5518, 5.7057],
  [-72.5161, 8.1205],
]
const SOURCE_ID = 'sitios'
const LAYER_ID = 'sitios-circulos'
const HALO_ID = 'sitios-halo'
const POR_PAGINA = 5

const MAP_STYLE: StyleSpecification = {
  version: 8,
  sources: {
    'esri-satellite': {
      type: 'raster',
      tiles: [
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      ],
      tileSize: 256,
      attribution: 'Tiles © Esri',
      maxzoom: 19,
    },
    'carto-labels': {
      type: 'raster',
      tiles: [
        'https://a.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}@2x.png',
        'https://b.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}@2x.png',
      ],
      tileSize: 256,
      maxzoom: 19,
    },
  },
  layers: [
    { id: 'satellite', type: 'raster', source: 'esri-satellite' },
    { id: 'labels', type: 'raster', source: 'carto-labels' },
  ],
}

/** Distancia aproximada en km entre dos coordenadas (haversine). */
function distanciaKm(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const R = 6371
  const dLat = ((bLat - aLat) * Math.PI) / 180
  const dLng = ((bLng - aLng) * Math.PI) / 180
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((aLat * Math.PI) / 180) * Math.cos((bLat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(s))
}

/** Sitios cercanos a uno dado: hasta 6 dentro de 12 km; si no, los 3 más próximos. */
function cercanosDe(sitio: SitioMapa, todos: SitioMapa[]): SitioMapa[] {
  const conDist = todos
    .filter((s) => s.id !== sitio.id)
    .map((s) => ({ s, d: distanciaKm(sitio.lat, sitio.lng, s.lat, s.lng) }))
    .sort((a, b) => a.d - b.d)
  const dentro = conDist.filter((x) => x.d <= 12)
  return (dentro.length ? dentro : conDist.slice(0, 3)).slice(0, 6).map((x) => x.s)
}

export function MapaSantander() {
  const cargar = useCallback(() => sitiosMapaService.listar(), [])
  const { datos, cargando } = useListado<SitioMapa>(cargar, 'No se pudo cargar el mapa.')

  const mapasOK = useConsentStore((s) => s.mapas)
  const activarCategoria = useConsentStore((s) => s.activarCategoria)

  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<maplibregl.Map | null>(null)
  const [ready, setReady] = useState(false)

  const [modalidad, setModalidad] = useState<ModalidadId | 'todas'>('todas')
  const [tipo, setTipo] = useState<TipoLugar | 'todos'>('todos')
  /** Ancla: define el encuadre y el conjunto de cercanos. */
  const [ancla, setAncla] = useState<SitioMapa | null>(null)
  /** Punto ACTIVO (el que se está mirando). No cambia el encuadre. */
  const [activoId, setActivoId] = useState<number | null>(null)
  const [filtrosAbiertos, setFiltrosAbiertos] = useState(true)
  const [listaAbierta, setListaAbierta] = useState(true)
  const [pagina, setPagina] = useState(0)

  const indice = useMemo(() => new Map(datos.map((s) => [s.id, s])), [datos])

  // El mapa se crea UNA vez; su handler de clic no puede leer estado del render
  // en que se creó (quedaría congelado). Estas refs le dan el valor actual.
  const indiceRef = useRef(indice)
  useEffect(() => {
    indiceRef.current = indice
  }, [indice])
  const anclaRef = useRef<SitioMapa | null>(null)

  const filtrados = useMemo(
    () =>
      datos.filter(
        (s) =>
          (modalidad === 'todas' || s.modalidad === modalidad) &&
          (tipo === 'todos' || s.tipo === tipo),
      ),
    [datos, modalidad, tipo],
  )

  const cercanos = useMemo(() => (ancla ? cercanosDe(ancla, datos) : []), [ancla, datos])

  /** Puntos dibujados: con ancla, el ancla + sus cercanos; si no, los filtrados. */
  const visibles = useMemo(
    () => (ancla ? [ancla, ...cercanos] : filtrados),
    [ancla, cercanos, filtrados],
  )

  const activo = activoId != null ? (indice.get(activoId) ?? null) : null
  const detalle = activo ?? ancla

  const geojson = useMemo<FeatureCollection<Point>>(
    () => ({
      type: 'FeatureCollection',
      features: visibles.map((s) => ({
        type: 'Feature',
        id: s.id,
        geometry: { type: 'Point', coordinates: [s.lng, s.lat] },
        properties: {
          color: MODALIDADES[s.modalidad].color,
          estado: s.id === activoId ? 'activo' : ancla ? 'cerca' : 'normal',
        },
      })),
    }),
    [visibles, activoId, ancla],
  )

  // Init del mapa (solo con consentimiento de mapas).
  useEffect(() => {
    if (!containerRef.current || !mapasOK) return
    const map = new maplibregl.Map({
      container: containerRef.current,
      style: MAP_STYLE,
      center: CENTRO_SANTANDER,
      zoom: 7.3,
      minZoom: 6.5,
      maxZoom: 17,
      attributionControl: false,
    })
    mapRef.current = map
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right')

    map.on('load', () => {
      map.addSource(SOURCE_ID, { type: 'geojson', data: geojson })

      // Halo del punto ACTIVO: lo hace inconfundible frente a los cercanos.
      map.addLayer({
        id: HALO_ID,
        type: 'circle',
        source: SOURCE_ID,
        filter: ['==', ['get', 'estado'], 'activo'],
        paint: {
          'circle-radius': 26,
          'circle-color': '#ffd166',
          'circle-opacity': 0.28,
          'circle-blur': 0.35,
        },
      })

      map.addLayer({
        id: LAYER_ID,
        type: 'circle',
        source: SOURCE_ID,
        paint: {
          'circle-radius': ['match', ['get', 'estado'], 'activo', 13, 'cerca', 7, 6] as never,
          'circle-color': ['get', 'color'] as never,
          'circle-stroke-width': ['match', ['get', 'estado'], 'activo', 5, 2] as never,
          'circle-stroke-color': [
            'match',
            ['get', 'estado'],
            'activo',
            '#ffd166',
            '#ffffff',
          ] as never,
          'circle-opacity': 0.97,
        },
      })

      map.on('click', LAYER_ID, (e) => {
        const f = e.features?.[0] as MapGeoJSONFeature | undefined
        if (f?.id == null) return
        const s = indiceRef.current.get(f.id as number)
        if (!s) return
        // Con ancla activa, tocar otro punto solo lo DESTACA (no recarga el mapa).
        setActivoId(s.id)
        if (!anclaRef.current) setAncla(s)
      })
      map.on('mouseenter', LAYER_ID, () => (map.getCanvas().style.cursor = 'pointer'))
      map.on('mouseleave', LAYER_ID, () => (map.getCanvas().style.cursor = ''))

      // Contorno real de Santander con borde TRICOLOR de la bandera.
      fetch(asset('/data/santander-poligono.json'))
        .then((r) => r.json())
        .then((poly) => {
          if (!mapRef.current || map.getSource('santander')) return
          map.addSource('santander', { type: 'geojson', data: poly })
          map.addLayer(
            {
              id: 'santander-fill',
              type: 'fill',
              source: 'santander',
              paint: { 'fill-color': '#1a6b3c', 'fill-opacity': 0.1 },
            },
            HALO_ID,
          )
          const BANDERA: [string, number][] = [
            ['#0a7a3d', 9],
            ['#f5c518', 6],
            ['#d81e05', 3],
          ]
          BANDERA.forEach(([color, width], i) => {
            map.addLayer(
              {
                id: `santander-line-${i}`,
                type: 'line',
                source: 'santander',
                layout: { 'line-join': 'round', 'line-cap': 'round' },
                paint: { 'line-color': color, 'line-width': width },
              },
              HALO_ID,
            )
          })
        })
        .catch(() => undefined)

      setReady(true)
    })

    return () => {
      map.remove()
      mapRef.current = null
      setReady(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mapasOK])

  // Datos del mapa (filtros / selección / destacado) sin recrear el mapa.
  useEffect(() => {
    const map = mapRef.current
    if (!map || !ready) return
    const src = map.getSource(SOURCE_ID) as maplibregl.GeoJSONSource | undefined
    src?.setData(geojson)
  }, [geojson, ready])

  // Encuadre: SOLO depende del ancla. Elegir un cercano no recarga la vista.
  useEffect(() => {
    anclaRef.current = ancla
    const map = mapRef.current
    if (!map || !ready) return
    if (ancla) {
      const bounds = new maplibregl.LngLatBounds()
      ;[ancla, ...cercanosDe(ancla, datos)].forEach((s) => bounds.extend([s.lng, s.lat]))
      map.fitBounds(bounds, {
        padding: { top: 70, bottom: 70, left: 360, right: 330 },
        maxZoom: 13.5,
        duration: 1200,
      })
    } else {
      map.fitBounds(SANTANDER_BOUNDS, { padding: 30, duration: 1000 })
    }
  }, [ancla, datos, ready])

  const cambiarModalidad = (m: string) => {
    setAncla(null)
    setActivoId(null)
    setPagina(0)
    setModalidad(m === 'todos' ? 'todas' : (m as ModalidadId))
  }
  const cambiarTipo = (t: string) => {
    setAncla(null)
    setActivoId(null)
    setPagina(0)
    setTipo(t === 'todos' ? 'todos' : (t as TipoLugar))
  }
  const limpiar = () => {
    setAncla(null)
    setActivoId(null)
    setPagina(0)
  }

  // Lista paginada (cliente hoy; misma UI si mañana pagina el backend).
  const fuenteLista = ancla ? cercanos : filtrados
  const paginas = Math.max(1, Math.ceil(fuenteLista.length / POR_PAGINA))
  const pag = Math.min(pagina, paginas - 1)
  const listaPagina = fuenteLista.slice(pag * POR_PAGINA, (pag + 1) * POR_PAGINA)

  const opcionesModalidad = MODALIDAD_KEYS.map((k) => ({
    id: k,
    label: MODALIDADES[k].label.replace('Turismo ', ''),
    icono: MODALIDADES[k].icono,
    color: MODALIDADES[k].color,
  }))
  const opcionesTipo = TIPO_LUGAR_KEYS.map((k) => ({
    id: k,
    label: TIPOS_LUGAR[k].label,
    icono: TIPOS_LUGAR[k].icono,
  }))

  return (
    <section className={styles.section} aria-label="Mapa de sitios turísticos de Santander">
      <Container maxWidth={1300}>
        <SectionHeader
          title="Mapa de Santander"
          subtitle="Sitios turísticos y lugares de interés. Filtra por modalidad o tipo, y toca un punto para ver qué hay cerca."
          align="center"
        />

        <div className={styles.mapWrap}>
          {mapasOK ? (
            <div
              ref={containerRef}
              className={styles.map}
              role="application"
              aria-label={`Mapa con ${visibles.length} sitios. Usa la lista lateral para abrirlos con el teclado.`}
            />
          ) : (
            <div className={`${styles.map} ${styles.placeholder}`}>
              <div className={styles.consentBox} role="note">
                <p>
                  El mapa carga imágenes de proveedores externos (Esri, Carto). Actívalo para verlo;
                  también puedes explorar los sitios en la lista.
                </p>
                <button
                  type="button"
                  className={styles.consentBtn}
                  onClick={() => activarCategoria('mapas')}
                >
                  Activar el mapa
                </button>
              </div>
            </div>
          )}

          {/* Filtros sobre el mapa, plegables y paginados */}
          <div className={`${styles.flotante} ${styles.filtros}`}>
            <button
              type="button"
              className={styles.toggle}
              onClick={() => setFiltrosAbiertos((o) => !o)}
              aria-expanded={filtrosAbiertos}
            >
              <span>
                <span aria-hidden="true">⚙</span> Filtros
              </span>
              <span aria-hidden="true">{filtrosAbiertos ? '−' : '+'}</span>
            </button>

            {filtrosAbiertos && (
              <div className={styles.cuerpo}>
                <GrupoChips
                  titulo="Modalidad de turismo"
                  opciones={opcionesModalidad}
                  valor={modalidad === 'todas' ? 'todos' : modalidad}
                  todosLabel="Todas"
                  onChange={cambiarModalidad}
                />
                <GrupoChips
                  titulo="Tipo de lugar"
                  opciones={opcionesTipo}
                  valor={tipo}
                  todosLabel="Todos"
                  onChange={cambiarTipo}
                />
              </div>
            )}
          </div>

          {/* Lista / detalle sobre el mapa, plegable y paginada */}
          <aside className={`${styles.flotante} ${styles.panel}`} aria-live="polite">
            <button
              type="button"
              className={styles.toggle}
              onClick={() => setListaAbierta((o) => !o)}
              aria-expanded={listaAbierta}
            >
              <span>{ancla ? 'Cercanos' : `Lugares (${filtrados.length})`}</span>
              <span aria-hidden="true">{listaAbierta ? '−' : '+'}</span>
            </button>

            {listaAbierta && (
              <div className={styles.cuerpo}>
                {detalle && (
                  <div className={styles.detalle}>
                    <button type="button" className={styles.volver} onClick={limpiar}>
                      ← Ver todo el mapa
                    </button>
                    <img src={detalle.img_url} alt="" className={styles.foto} />
                    <span
                      className={styles.badge}
                      style={{ background: MODALIDADES[detalle.modalidad].color }}
                    >
                      {TIPOS_LUGAR[detalle.tipo].icono} {TIPOS_LUGAR[detalle.tipo].label}
                    </span>
                    <h3 className={styles.nombre}>{detalle.nombre}</h3>
                    <p className={styles.muni}>{detalle.municipio}</p>
                    <p className={styles.desc}>{detalle.descripcion}</p>
                  </div>
                )}

                <p className={styles.conteo}>
                  {cargando
                    ? 'Cargando…'
                    : ancla
                      ? 'Sitios de interés cercanos'
                      : `${filtrados.length} lugares`}
                </p>

                <ul className={styles.lista}>
                  {listaPagina.map((s) => (
                    <li key={s.id}>
                      <button
                        type="button"
                        className={`${styles.item} ${s.id === activoId ? styles.itemOn : ''}`}
                        aria-current={s.id === activoId ? 'true' : undefined}
                        onClick={() => {
                          setActivoId(s.id)
                          if (!ancla) setAncla(s)
                        }}
                      >
                        <span aria-hidden="true" style={{ color: MODALIDADES[s.modalidad].color }}>
                          {TIPOS_LUGAR[s.tipo].icono}
                        </span>
                        <span>
                          <strong>{s.nombre}</strong>
                          <small>
                            {s.municipio} · {MODALIDADES[s.modalidad].label.replace('Turismo ', '')}
                          </small>
                        </span>
                      </button>
                    </li>
                  ))}
                  {!cargando && fuenteLista.length === 0 && (
                    <li className={styles.vacio}>No hay lugares con estos filtros.</li>
                  )}
                </ul>

                {paginas > 1 && (
                  <div className={styles.pag}>
                    <button
                      type="button"
                      className={styles.pagBtn}
                      onClick={() => setPagina((p) => Math.max(0, p - 1))}
                      disabled={pag === 0}
                      aria-label="Página anterior de lugares"
                    >
                      ‹
                    </button>
                    <span className={styles.pagInfo}>
                      {pag + 1} / {paginas}
                    </span>
                    <button
                      type="button"
                      className={styles.pagBtn}
                      onClick={() => setPagina((p) => Math.min(paginas - 1, p + 1))}
                      disabled={pag >= paginas - 1}
                      aria-label="Página siguiente de lugares"
                    >
                      ›
                    </button>
                  </div>
                )}
              </div>
            )}
          </aside>
        </div>
      </Container>
    </section>
  )
}
