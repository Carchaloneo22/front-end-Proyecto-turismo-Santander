import { useCallback, useEffect, useRef, useState } from 'react'
import { Card } from '../../ui/Card'
import { MODALIDADES } from '../../../features/experiencias/modalidades'
import type { Experiencia } from '../../../services'
import styles from './ExploraModalidades.module.css'

/**
 * Carrusel de experiencias estilo **cover flow**: la tarjeta centrada se ve a
 * tamaño completo y las laterales se encogen y atenúan según su distancia al
 * centro. El desplazamiento es scroll nativo con `scroll-snap`, así funciona con
 * gesto táctil, rueda y teclado; el efecto se calcula en el evento `scroll`.
 *
 * La diapositiva activa se deduce de la POSICIÓN de scroll (la más cercana al
 * centro), no de un IntersectionObserver: con varias tarjetas visibles a la vez
 * el observer no dice cuál es «la del medio», y las flechas quedaban erráticas.
 */
export function CarruselExperiencias({ items }: { items: Experiencia[] }) {
  const pistaRef = useRef<HTMLUListElement>(null)
  const [activo, setActivo] = useState(0)

  /** Aplica escala/opacidad según la distancia al centro y calcula el activo. */
  const pintar = useCallback(() => {
    const pista = pistaRef.current
    if (!pista) return
    const slides = Array.from(pista.querySelectorAll<HTMLElement>('[data-slide]'))
    if (slides.length === 0) return
    const centroPista = pista.scrollLeft + pista.clientWidth / 2
    let mejor = 0
    let mejorDist = Infinity
    slides.forEach((s, i) => {
      const centroSlide = s.offsetLeft + s.offsetWidth / 2
      const dist = Math.abs(centroSlide - centroPista)
      const ratio = Math.min(1, dist / (pista.clientWidth / 2))
      // Efecto suave: la del centro a tamaño completo, las laterales algo
      // menores pero SIEMPRE legibles (si se encogen mucho, el texto se parte).
      s.style.transform = `scale(${(1 - ratio * 0.12).toFixed(3)})`
      s.style.opacity = (1 - ratio * 0.3).toFixed(3)
      s.style.zIndex = String(10 - Math.round(ratio * 10))
      if (dist < mejorDist) {
        mejorDist = dist
        mejor = i
      }
    })
    setActivo(mejor)
  }, [])

  // Repinta al hacer scroll (con rAF para no saturar) y al redimensionar.
  useEffect(() => {
    const pista = pistaRef.current
    if (!pista) return
    let pendiente = false
    const alScroll = () => {
      if (pendiente) return
      pendiente = true
      requestAnimationFrame(() => {
        pendiente = false
        pintar()
      })
    }
    pista.addEventListener('scroll', alScroll, { passive: true })
    window.addEventListener('resize', alScroll)
    pintar()
    return () => {
      pista.removeEventListener('scroll', alScroll)
      window.removeEventListener('resize', alScroll)
    }
  }, [pintar, items])

  /**
   * Centra la diapositiva `i`. Se calcula el `scrollLeft` a mano en vez de usar
   * `scrollIntoView`, que además arrastraría el scroll de la página.
   */
  const irA = (i: number) => {
    const pista = pistaRef.current
    if (!pista) return
    const slide = pista.querySelectorAll<HTMLElement>('[data-slide]')[i]
    if (!slide) return
    const suave = !window.matchMedia('(prefers-reduced-motion: reduce)').matches
    pista.scrollTo({
      left: slide.offsetLeft - (pista.clientWidth - slide.offsetWidth) / 2,
      behavior: suave ? 'smooth' : 'auto',
    })
  }

  return (
    <div className={styles.carruselWrap} aria-roledescription="carrusel">
      <button
        type="button"
        className={`${styles.nav} ${styles.navPrev}`}
        onClick={() => irA(Math.max(0, activo - 1))}
        disabled={activo === 0}
        aria-label="Experiencia anterior"
      >
        ‹
      </button>

      <ul ref={pistaRef} className={styles.pista}>
        {items.map((e, i) => (
          <li
            key={e.id}
            data-slide
            className={styles.slide}
            aria-roledescription="diapositiva"
            aria-label={`${i + 1} de ${items.length}: ${e.nombre}`}
          >
            <Card
              image={e.img_url}
              imageAlt={`${e.nombre}, ${e.municipio}`}
              badge={`${MODALIDADES[e.modalidad].icono} ${MODALIDADES[e.modalidad].label.replace('Turismo ', '')}`}
              title={e.nombre}
              description={`${e.municipio} — ${e.descripcion}`}
            />
          </li>
        ))}
      </ul>

      <button
        type="button"
        className={`${styles.nav} ${styles.navNext}`}
        onClick={() => irA(Math.min(items.length - 1, activo + 1))}
        disabled={activo >= items.length - 1}
        aria-label="Experiencia siguiente"
      >
        ›
      </button>

      {/* Miniaturas de navegación (los «dots», con la foto de cada sitio). */}
      <div className={styles.minis} role="tablist" aria-label="Ir a una experiencia">
        {items.map((e, i) => (
          <button
            key={e.id}
            type="button"
            role="tab"
            aria-selected={i === activo}
            aria-label={e.nombre}
            className={`${styles.mini} ${i === activo ? styles.miniOn : ''}`}
            onClick={() => irA(i)}
          >
            <img src={e.img_url} alt="" />
          </button>
        ))}
      </div>
    </div>
  )
}
