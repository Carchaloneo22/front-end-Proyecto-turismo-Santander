import { useCallback, useMemo, useState } from 'react'
import { Container } from '../../ui/Container'
import { SectionHeader } from '../../ui/SectionHeader'
import { SkeletonCard } from '../../ui/Skeleton'
import { useListado } from '../../../hooks/useListado'
import { experienciasService, type Experiencia } from '../../../services'
import {
  MODALIDADES,
  MODALIDAD_KEYS,
  type ModalidadId,
} from '../../../features/experiencias/modalidades'
import { CarruselExperiencias } from './CarruselExperiencias'
import styles from './ExploraModalidades.module.css'

type Orden = 'relevancia' | 'nombre' | 'municipio'
/** Tamaño de lote. Hoy se corta en cliente; mañana es el `limit` del backend. */
const POR_LOTE = 8
/** Chips visibles antes de desplegar el resto. */
const CHIPS_VISIBLES = 3

export function ExploraModalidades() {
  const cargar = useCallback(() => experienciasService.listar(), [])
  const { datos, cargando, error } = useListado<Experiencia>(
    cargar,
    'No se pudieron cargar las experiencias.',
  )

  const [q, setQ] = useState('')
  const [modalidad, setModalidad] = useState<ModalidadId | 'todas'>('todas')
  const [orden, setOrden] = useState<Orden>('relevancia')
  const [lote, setLote] = useState(1)
  const [verTodos, setVerTodos] = useState(false)

  const conteos = useMemo(() => {
    const c: Record<string, number> = {}
    for (const e of datos) c[e.modalidad] = (c[e.modalidad] ?? 0) + 1
    return c
  }, [datos])

  const filtradas = useMemo(() => {
    const texto = q.trim().toLowerCase()
    let lista = datos.filter((e) => {
      const okMod = modalidad === 'todas' || e.modalidad === modalidad
      const okTxt =
        !texto ||
        e.nombre.toLowerCase().includes(texto) ||
        e.municipio.toLowerCase().includes(texto) ||
        e.descripcion.toLowerCase().includes(texto)
      return okMod && okTxt
    })
    if (orden === 'nombre') lista = [...lista].sort((a, b) => a.nombre.localeCompare(b.nombre))
    else if (orden === 'municipio')
      lista = [...lista].sort((a, b) => a.municipio.localeCompare(b.municipio))
    return lista
  }, [datos, q, modalidad, orden])

  const visibles = filtradas.slice(0, lote * POR_LOTE)
  const hayMas = visibles.length < filtradas.length

  // Al cambiar un criterio se vuelve al primer lote (desde el handler, no en un
  // efecto: así no se encadenan renders).
  const cambiarModalidad = (m: ModalidadId | 'todas') => {
    setModalidad(m)
    setLote(1)
  }
  const cambiarBusqueda = (v: string) => {
    setQ(v)
    setLote(1)
  }
  const cambiarOrden = (o: Orden) => {
    setOrden(o)
    setLote(1)
  }

  const chips = verTodos ? MODALIDAD_KEYS : MODALIDAD_KEYS.slice(0, CHIPS_VISIBLES)
  const ocultos = MODALIDAD_KEYS.length - CHIPS_VISIBLES

  return (
    <section className={styles.section} aria-label="Explora Santander por modalidad de turismo">
      <Container maxWidth={1200}>
        <SectionHeader
          title="Explora Santander por modalidad de turismo"
          subtitle="Encuentra experiencias según tu interés: aventura, naturaleza, cultura y más."
          align="center"
        />

        {/* Barra compacta: búsqueda + filtros + orden en una sola línea */}
        <div className={styles.barra}>
          <div className={styles.buscador}>
            <span className={styles.lupa} aria-hidden="true">
              🔎
            </span>
            <input
              type="search"
              className={styles.input}
              placeholder="Busca por nombre, municipio o palabra clave…"
              aria-label="Buscar experiencias"
              value={q}
              onChange={(e) => cambiarBusqueda(e.target.value)}
            />
          </div>

          <label className={styles.orden}>
            <span className={styles.ordenLbl}>Ordenar</span>
            <select value={orden} onChange={(e) => cambiarOrden(e.target.value as Orden)}>
              <option value="relevancia">Relevancia</option>
              <option value="nombre">Nombre (A–Z)</option>
              <option value="municipio">Municipio (A–Z)</option>
            </select>
          </label>
        </div>

        {/* Chips en UNA fila; el resto se despliega con «+ N más» */}
        <div className={styles.chips} role="group" aria-label="Filtrar por modalidad de turismo">
          <button
            type="button"
            className={`${styles.chip} ${modalidad === 'todas' ? styles.chipOn : ''}`}
            aria-pressed={modalidad === 'todas'}
            onClick={() => cambiarModalidad('todas')}
          >
            Todas <span className={styles.n}>{datos.length}</span>
          </button>
          {chips.map((k) => (
            <button
              key={k}
              type="button"
              className={`${styles.chip} ${modalidad === k ? styles.chipOn : ''}`}
              style={
                modalidad === k
                  ? { background: MODALIDADES[k].color, borderColor: MODALIDADES[k].color }
                  : undefined
              }
              aria-pressed={modalidad === k}
              onClick={() => cambiarModalidad(k)}
              title={MODALIDADES[k].label}
            >
              <span aria-hidden="true">{MODALIDADES[k].icono}</span>{' '}
              {MODALIDADES[k].label.replace('Turismo ', '')}
              <span className={styles.n}>{conteos[k] ?? 0}</span>
            </button>
          ))}
          {ocultos > 0 && (
            <button
              type="button"
              className={`${styles.chip} ${styles.chipMas}`}
              aria-expanded={verTodos}
              onClick={() => setVerTodos((v) => !v)}
            >
              {verTodos ? '− menos' : `+ ${ocultos} más`}
            </button>
          )}
        </div>

        <p className={styles.conteo} aria-live="polite">
          {cargando
            ? 'Cargando…'
            : `${filtradas.length} experiencia${filtradas.length === 1 ? '' : 's'}`}
        </p>

        {/* Contenido */}
        {cargando ? (
          <div className={styles.gridCarga}>
            {Array.from({ length: 4 }, (_, i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        ) : error ? (
          <p className={styles.vacio} role="alert">
            {error}
          </p>
        ) : visibles.length === 0 ? (
          <p className={styles.vacio}>No hay experiencias que coincidan con tu búsqueda.</p>
        ) : (
          <>
            <CarruselExperiencias items={visibles} />
            {hayMas && (
              <div className={styles.masWrap}>
                <button
                  type="button"
                  className={styles.masBtn}
                  onClick={() => setLote((l) => l + 1)}
                >
                  Cargar más experiencias ({filtradas.length - visibles.length} restantes)
                </button>
              </div>
            )}
          </>
        )}
      </Container>
    </section>
  )
}
