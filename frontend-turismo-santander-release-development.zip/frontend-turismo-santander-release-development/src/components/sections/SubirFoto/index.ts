export { SubirFoto } from './SubirFoto'
