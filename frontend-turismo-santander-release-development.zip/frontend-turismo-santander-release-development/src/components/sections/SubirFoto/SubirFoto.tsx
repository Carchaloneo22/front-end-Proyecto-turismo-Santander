import { useState } from 'react'
import { Modal } from '../../ui/Modal'
import { Heading } from '../../ui/Heading'
import { Text } from '../../ui/Text'
import { Button } from '../../ui/Button'
import { authService, subidasService } from '../../../services'
// Las categorías provienen de CATEGORIAS (fuente única de verdad), evitando que
// nuevos registros en el sistema queden desactualizados en el formulario.
import { CATEGORIAS, CATEGORIA_KEYS } from '../../../features/destinos'
import type { CategoriaSitio } from '../../../features/destinos'
import { optimizarImagen, validarArchivo } from '../../../lib/archivos'
import styles from './SubirFoto.module.css'

/** Límite que promete la UI ("máx. 25 MB") — ahora también se hace cumplir. */
const MAX_BYTES = 25 * 1024 * 1024

type Paso = 'entrar' | 'subir'

/**
 * SubirFoto — Módulo unificado para la carga de imágenes por casas de cultura.
 *
 * Flujo simplificado de dos pasos (autenticación y carga).
 * La validación previa de proporciones en cliente reduce el consumo de ancho de banda,
 * pero la validación final se centraliza en el backend (subidas/validador.php).
 */
export function SubirFoto() {
  const [modalOpen, setModalOpen] = useState(false)
  const [paso, setPaso] = useState<Paso>('entrar')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [sitio, setSitio] = useState('')
  const [tipo, setTipo] = useState<'360' | 'plana'>('360')
  const [categoria, setCategoria] = useState<CategoriaSitio>('contemplativo')
  const [descripcion, setDescripcion] = useState('')
  const [archivo, setArchivo] = useState<File | null>(null)
  const [aviso, setAviso] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [exito, setExito] = useState<string | null>(null)
  const [ocupado, setOcupado] = useState(false)
  const [progreso, setProgreso] = useState(0)

  async function entrar(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setOcupado(true)
    try {
      await authService.login({ email, password, tipo: 'casa_cultura' })
      setPaso('subir')
    } catch (err: unknown) {
      const api = err as { message?: string }
      setError(api?.message ?? 'No se pudo iniciar sesión.')
    } finally {
      setOcupado(false)
    }
  }

  /**
   * Valida el archivo en el navegador antes de aceptarlo: tamaño, formato real
   * (magic bytes, no solo la extensión) y, para 360°, la relación de aspecto.
   * Los fallos de seguridad/formato BLOQUEAN (error); la proporción solo avisa
   * — la validación final la hace el backend.
   */
  async function revisar(f: File) {
    setArchivo(null)
    setAviso(null)
    setError(null)

    const r = await validarArchivo(f, { maxBytes: MAX_BYTES })
    if (!r.ok) {
      setError(r.error)
      return
    }
    setArchivo(f)

    if (tipo === '360' && r.dimensiones) {
      const { ancho, alto } = r.dimensiones
      const ratio = ancho / alto
      if (Math.abs(ratio - 2) > 0.01) {
        setAviso(
          `Esta imagen es ${ancho}×${alto} (proporción ${ratio.toFixed(2)}:1). ` +
            `Una panorámica 360° debe ser de proporción 2:1 exacta. ` +
            `Se recomienda exportar a ${ancho}×${Math.round(ancho / 2)}.`,
        )
      }
    }
  }

  async function subir(e: React.FormEvent) {
    e.preventDefault()
    if (!archivo) return
    setError(null)
    setOcupado(true)
    setProgreso(0)
    // Las fotos planas se re-codifican a WebP en el navegador: pesan menos y
    // pierden los metadatos EXIF/GPS. Las 360° viajan intactas (el backend las
    // optimiza sin tocar su resolución, que el visor necesita completa).
    const paraSubir =
      tipo === 'plana' ? await optimizarImagen(archivo, { maxAncho: 2560 }) : archivo
    const r = await subidasService.subir(
      paraSubir,
      { sitio, tipo, descripcion, categoria: tipo === '360' ? categoria : undefined },
      setProgreso,
    )
    setOcupado(false)
    if (r.ok) {
      setExito(`Listo. ${sitio} (${r.dimensiones}) ya está publicada en ${r.municipio}.`)
      setArchivo(null)
      setSitio('')
      setDescripcion('')
      setAviso(null)
    } else {
      setError(r.error ?? 'No se pudo subir.')
    }
  }

  return (
    <>
      {/* Sección visible en la Landing Page */}
      <section className={styles.seccion}>
        <div className={styles.iconoCamaraCirculo} aria-hidden="true">
          <svg viewBox="0 0 24 24">
            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
            <circle cx="12" cy="13" r="4" />
          </svg>
        </div>

        <h3 className={styles.pregunta}>¿Eres de una casa de cultura?</h3>

        <button type="button" className={styles.botonAbrir} onClick={() => setModalOpen(true)}>
          Subir fotografías de tu municipio <span>→</span>
        </button>
      </section>

      {/* Modal de autenticación y carga */}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} titleId="subir-foto-titulo">
        <div className={styles.caja}>
          {paso === 'entrar' ? (
            <form onSubmit={entrar} className={styles.form}>
              <Heading level={2} size={4} id="subir-foto-titulo">
                Casas de cultura
              </Heading>
              <Text size="sm" muted>
                Entra con el usuario de tu casa de cultura para subir fotografías de tu municipio.
              </Text>

              <label className={styles.campo}>
                <span>Correo</span>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  autoComplete="username"
                />
              </label>
              <label className={styles.campo}>
                <span>Contraseña</span>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  autoComplete="current-password"
                />
              </label>

              {error && (
                <p className={styles.error} role="alert">
                  {error}
                </p>
              )}
              <Button
                type="submit"
                fullWidth
                disabled={ocupado}
                bg="var(--brand-green, #008744)"
                textColor="#fff"
              >
                {ocupado ? 'Entrando…' : 'Entrar'}
              </Button>
            </form>
          ) : (
            <form onSubmit={subir} className={styles.form}>
              <Heading level={2} size={4} id="subir-foto-titulo">
                Subir fotografía
              </Heading>

              <label className={styles.campo}>
                <span>Nombre del sitio</span>
                <input
                  type="text"
                  value={sitio}
                  onChange={(e) => setSitio(e.target.value)}
                  required
                  placeholder="Parque Principal de Barichara"
                />
              </label>

              <fieldset className={styles.tipos}>
                <legend>Tipo de fotografía</legend>
                {(['360', 'plana'] as const).map((t) => (
                  <label key={t}>
                    <input
                      type="radio"
                      name="tipo"
                      checked={tipo === t}
                      onChange={() => {
                        setTipo(t)
                        setAviso(null)
                      }}
                    />
                    {t === '360' ? 'Panorámica 360°' : 'Foto normal'}
                  </label>
                ))}
              </fieldset>

              {tipo === '360' && (
                <label className={styles.campo}>
                  <span>Tipo de lugar</span>
                  <select
                    value={categoria}
                    onChange={(e) => setCategoria(e.target.value as CategoriaSitio)}
                    required
                  >
                    {CATEGORIA_KEYS.map((k) => (
                      <option key={k} value={k}>
                        {CATEGORIAS[k].label}
                      </option>
                    ))}
                  </select>
                  <small>Define la categoría y marcador asociado en el mapa departamental.</small>
                </label>
              )}

              <label className={styles.campo}>
                <span>Archivo</span>
                <input
                  type="file"
                  accept="image/webp,image/jpeg,image/png"
                  onChange={(e) => e.target.files?.[0] && revisar(e.target.files[0])}
                  required
                />
                <small>
                  {tipo === '360'
                    ? 'Equirectangular 2:1 (4096×2048 o superior). WebP, JPG o PNG, máx. 25 MB.'
                    : 'Mínimo 1280 px de ancho. WebP, JPG o PNG, máx. 25 MB.'}
                </small>
              </label>

              <label className={styles.campo}>
                <span>Descripción (opcional)</span>
                <textarea
                  value={descripcion}
                  onChange={(e) => setDescripcion(e.target.value)}
                  rows={2}
                />
              </label>

              {aviso && (
                <p className={styles.aviso} role="alert">
                  {aviso}
                </p>
              )}
              {error && (
                <p className={styles.error} role="alert">
                  {error}
                </p>
              )}
              {exito && (
                <p className={styles.exito} role="status">
                  {exito}
                </p>
              )}

              {ocupado && (
                <div className={styles.barra} role="status" aria-label={`Subiendo ${progreso}%`}>
                  <div className={styles.relleno} style={{ width: `${progreso}%` }} />
                  <span>{progreso}%</span>
                </div>
              )}

              <Button
                type="submit"
                fullWidth
                disabled={ocupado || !archivo}
                bg="var(--brand-green, #008744)"
                textColor="#fff"
              >
                {ocupado ? 'Subiendo…' : 'Subir fotografía'}
              </Button>
            </form>
          )}
        </div>
      </Modal>
    </>
  )
}
