import { useCallback } from 'react'
import { Container } from '../../ui/Container'
import { SectionHeader } from '../../ui/SectionHeader'
import { useListado } from '../../../hooks/useListado'
import { resenasService } from '../../../services'
import type { Resena } from '../../../services/ResenasService'
import styles from './Testimonios.module.css'

function Estrellas({ n }: { n: number }) {
  const llenas = Math.max(0, Math.min(5, Math.round(n)))
  return (
    <span className={styles.estrellas} aria-label={`${llenas} de 5 estrellas`}>
      <span aria-hidden="true">
        {'★'.repeat(llenas)}
        {'☆'.repeat(5 - llenas)}
      </span>
    </span>
  )
}

/**
 * Sección de reseñas / testimonios de viajeros. Se alimenta de `resenasService`,
 * que en modo presentación sirve `public/data/resenas.json`. Si no hay reseñas,
 * la sección no se muestra (no deja un hueco vacío).
 */
export function Testimonios() {
  const cargar = useCallback(() => resenasService.listar(), [])
  const { datos, cargando } = useListado<Resena>(cargar, 'No se pudieron cargar las reseñas.')

  if (!cargando && datos.length === 0) return null

  return (
    <section className={styles.section} aria-label="Reseñas de viajeros">
      <Container maxWidth={1200}>
        <SectionHeader
          title="Lo que dicen los viajeros"
          subtitle="Experiencias reales de quienes han recorrido Santander con nosotros."
          align="center"
        />
        <ul className={styles.grid}>
          {datos.map((r) => (
            <li key={r.id} className={styles.card}>
              <Estrellas n={r.calificacion} />
              <p className={styles.texto}>“{r.contenido}”</p>
              <p className={styles.autor}>{r.autor}</p>
            </li>
          ))}
        </ul>
      </Container>
    </section>
  )
}
