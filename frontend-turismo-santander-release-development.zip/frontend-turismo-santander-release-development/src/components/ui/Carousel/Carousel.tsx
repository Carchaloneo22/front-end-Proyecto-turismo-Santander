import { useCallback, useRef, useState, type KeyboardEvent } from 'react'
import { useGSAP } from '@gsap/react'
import gsap from 'gsap'
import { useReducedMotion } from '../../../hooks/useReducedMotion'
import type { CarouselProps } from './Carousel.types'
import styles from './Carousel.module.css'

/**
 * Carousel — átomo genérico y accesible con animación GSAP (efecto "coverflow":
 * la diapositiva activa se centra y crece, las demás se atenúan).
 *
 * SOLID:
 * - SRP: solo gestiona layout, animación y accesibilidad del carrusel.
 * - OCP: no conoce el contenido; se extiende vía `renderItem` sin modificarlo.
 * - DRY: la animación GSAP vive aquí, no repartida por cada página.
 *
 * Accesibilidad (WCAG 2.2):
 * - Región con `aria-roledescription="carrusel"` + label.
 * - Flechas con `aria-label`; navegación con ← →, Inicio/Fin.
 * - Diapositivas no activas quedan `inert`/`aria-hidden` (no reciben foco).
 * - Estado anunciado por una región `aria-live="polite"`.
 * - Respeta `prefers-reduced-motion`: sin animación, salto directo.
 */
export function Carousel<T>({
  items,
  renderItem,
  getKey,
  getItemLabel,
  ariaLabel,
  initialIndex = 0,
  onActiveChange,
  className = '',
}: CarouselProps<T>) {
  const [active, setActive] = useState(initialIndex)
  const reduce = useReducedMotion()
  const viewportRef = useRef<HTMLDivElement>(null)
  const trackRef = useRef<HTMLUListElement>(null)

  const goTo = useCallback(
    (index: number) => {
      const clamped = Math.max(0, Math.min(index, items.length - 1))
      setActive(clamped)
      onActiveChange?.(clamped)
    },
    [items.length, onActiveChange],
  )

  // Centra la diapositiva activa y resalta con GSAP. Se re-ejecuta al cambiar
  // `active`, `reduce` o el nº de items; también en resize (medimos el DOM real).
  useGSAP(
    () => {
      const track = trackRef.current
      const viewport = viewportRef.current
      if (!track || !viewport) return

      const layout = () => {
        const slides = Array.from(track.children) as HTMLElement[]
        const activeEl = slides[active]
        if (!activeEl) return
        const targetX = viewport.clientWidth / 2 - (activeEl.offsetLeft + activeEl.offsetWidth / 2)

        const duration = reduce ? 0 : 0.7
        gsap.to(track, { x: targetX, duration, ease: 'power3.out' })
        slides.forEach((slide, i) => {
          gsap.to(slide, {
            scale: i === active ? 1 : 0.82,
            opacity: i === active ? 1 : 0.45,
            duration,
            ease: 'power3.out',
          })
        })
      }

      layout()
      window.addEventListener('resize', layout)
      return () => window.removeEventListener('resize', layout)
    },
    { dependencies: [active, reduce, items.length], scope: viewportRef },
  )

  const onKeyDown = (e: KeyboardEvent) => {
    if (e.key === 'ArrowRight') {
      e.preventDefault()
      goTo(active + 1)
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault()
      goTo(active - 1)
    } else if (e.key === 'Home') {
      e.preventDefault()
      goTo(0)
    } else if (e.key === 'End') {
      e.preventDefault()
      goTo(items.length - 1)
    }
  }

  const activeLabel = getItemLabel?.(items[active], active)

  return (
    <div
      className={`${styles.carousel} ${className}`}
      role="group"
      aria-roledescription="carrusel"
      aria-label={ariaLabel}
      onKeyDown={onKeyDown}
    >
      <div className={styles.viewport} ref={viewportRef}>
        <ul className={styles.track} ref={trackRef}>
          {items.map((item, i) => {
            const isActive = i === active
            const label = getItemLabel?.(item, i)
            return (
              <li
                key={getKey(item, i)}
                className={styles.slide}
                role="group"
                aria-roledescription="diapositiva"
                aria-label={
                  label ? `${label} (${i + 1} de ${items.length})` : `${i + 1} de ${items.length}`
                }
                aria-hidden={!isActive}
                // `inert`: las diapositivas ocultas no reciben foco ni clic por teclado.
                inert={!isActive}
                onClick={() => !isActive && goTo(i)}
              >
                {renderItem(item, i, isActive)}
              </li>
            )
          })}
        </ul>
      </div>

      <div className={styles.controls}>
        <button
          type="button"
          className={styles.arrow}
          aria-label="Diapositiva anterior"
          onClick={() => goTo(active - 1)}
          disabled={active === 0}
        >
          ‹
        </button>

        <div className={styles.dots} role="tablist" aria-label="Ir a diapositiva">
          {items.map((item, i) => (
            <button
              type="button"
              key={getKey(item, i)}
              role="tab"
              aria-selected={i === active}
              aria-label={`Diapositiva ${i + 1}${getItemLabel ? `: ${getItemLabel(item, i)}` : ''}`}
              className={`${styles.dot} ${i === active ? styles.dotActive : ''}`}
              onClick={() => goTo(i)}
            />
          ))}
        </div>

        <button
          type="button"
          className={styles.arrow}
          aria-label="Diapositiva siguiente"
          onClick={() => goTo(active + 1)}
          disabled={active === items.length - 1}
        >
          ›
        </button>
      </div>

      {/* Anuncio para lectores de pantalla al cambiar de diapositiva. */}
      <p className={styles.srStatus} aria-live="polite">
        {activeLabel
          ? `Diapositiva ${active + 1} de ${items.length}: ${activeLabel}`
          : `Diapositiva ${active + 1} de ${items.length}`}
      </p>
    </div>
  )
}
