import type { ReactNode } from 'react'

export interface CarouselProps<T> {
  /** Datos de las diapositivas. El Carousel no sabe qué son (open/closed). */
  items: T[]
  /** Render de cada diapositiva. Recibe si está activa para resaltarla. */
  renderItem: (item: T, index: number, isActive: boolean) => ReactNode
  /** Clave estable por item (evita índices como key). */
  getKey: (item: T, index: number) => string
  /** Texto accesible por item: se anuncia en aria-live y como label de la diapositiva. */
  getItemLabel?: (item: T, index: number) => string
  /** Etiqueta del carrusel completo (aria-label de la región). */
  ariaLabel: string
  /** Índice inicial. */
  initialIndex?: number
  /** Notifica cambios de diapositiva activa (opcional). */
  onActiveChange?: (index: number) => void
  className?: string
}

/** Tipo del render prop de flechas custom (por si un consumidor quiere las suyas). */
export type CarouselArrow = (props: { disabled: boolean; onClick: () => void }) => ReactNode
