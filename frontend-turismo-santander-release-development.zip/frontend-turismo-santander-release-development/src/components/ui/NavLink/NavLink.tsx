import { NavLink as RouterNavLink } from 'react-router-dom'
import type { ReactNode } from 'react'
import { useSignAttributes } from '../../../hooks/useSignAttributes'

export interface NavLinkProps {
  to: string
  children: ReactNode
  className?: string // clase base
  activeClassName?: string // clase cuando la ruta está activa
  onClick?: () => void
  signSrc?: string // Lengua de Señas: URL del video/imagen de la seña
}

/**
 * NavLink — átomo de navegación con estado ACTIVO. Envuelve react-router NavLink.
 * Expone activeClassName para que fuera de aquí nadie use el render-prop de la lib.
 */
export function NavLink({
  to,
  children,
  className = '',
  activeClassName = '',
  onClick,
  signSrc,
}: NavLinkProps) {
  const label = typeof children === 'string' ? children : undefined
  const sign = useSignAttributes(signSrc, label)
  return (
    <RouterNavLink
      to={to}
      onClick={onClick}
      className={({ isActive }) => `${className} ${isActive ? activeClassName : ''}`.trim()}
      {...sign}
    >
      {children}
    </RouterNavLink>
  )
}
