import type { CSSProperties } from 'react'
import styles from './Spinner.module.css'

interface SpinnerProps {
  /** Diámetro en px (o cualquier unidad CSS). */
  size?: number | string
  /** Grosor del anillo en px. */
  thickness?: number
  /** Color del arco que gira. Por defecto, el morado de marca. */
  color?: string
  /**
   * Texto accesible. Si se pasa, el spinner se anuncia como `role="status"`
   * (aria-live). Si se omite, es puramente decorativo (`aria-hidden`) — úsalo así
   * cuando el estado de carga ya lo anuncia un contenedor padre.
   */
  label?: string
  className?: string
}

/**
 * Spinner — átomo de carga reutilizable, configurable por props. Respeta
 * `prefers-reduced-motion` (gira más lento) desde el CSS. Cualquier feature
 * (carrito, login, fetch, VR…) lo reutiliza en vez de recrear el mismo círculo.
 */
export function Spinner({ size = 40, thickness = 4, color, label, className = '' }: SpinnerProps) {
  const style = {
    '--spinner-size': typeof size === 'number' ? `${size}px` : size,
    '--spinner-thickness': `${thickness}px`,
    '--spinner-color': color,
  } as CSSProperties

  const a11y = label
    ? { role: 'status' as const, 'aria-live': 'polite' as const, 'aria-label': label }
    : { 'aria-hidden': true }

  return <span className={`${styles.spinner} ${className}`} style={style} {...a11y} />
}
