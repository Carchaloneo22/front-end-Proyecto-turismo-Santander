import type { CSSProperties } from 'react'
import { useSignAttributes } from '../../../hooks/useSignAttributes'
import styles from './Button.module.css'
import type { ButtonProps } from './Button.types'

/**
 * Button — átomo 100% configurable por props.
 * Visual por props (variant/size/overrides) + handlers nativos vía ...rest.
 */
export function Button({
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  loading = false,
  iconLeft,
  iconRight,
  children,
  className = '',
  disabled,
  bg,
  textColor,
  radius,
  padding,
  fontSize,
  signSrc,
  style,
  ...rest
}: ButtonProps) {
  const label = typeof children === 'string' ? children : undefined
  const sign = useSignAttributes(signSrc, label)
  const classes = [
    styles.button,
    styles[variant],
    styles[size],
    fullWidth ? styles.fullWidth : '',
    className,
  ]
    .filter(Boolean)
    .join(' ')

  // Overrides por instancia → variables inline SOLO en este botón.
  const overrideStyle = {
    '--btn-bg': bg,
    '--btn-fg': textColor,
    '--btn-radius': radius,
    '--btn-padding': padding,
    '--btn-font-size': fontSize,
    ...style,
  } as CSSProperties

  return (
    <button
      className={classes}
      style={overrideStyle}
      disabled={disabled || loading}
      {...sign}
      {...rest}
    >
      {loading && <span className={styles.spinner} aria-hidden="true" />}
      {!loading && iconLeft}
      {children && <span>{children}</span>}
      {!loading && iconRight}
    </button>
  )
}
