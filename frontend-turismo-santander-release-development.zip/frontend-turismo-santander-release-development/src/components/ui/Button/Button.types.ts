import type { ButtonHTMLAttributes, ReactNode } from 'react'

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger'
export type ButtonSize = 'sm' | 'md' | 'lg'

/**
 * Extiende ButtonHTMLAttributes → hereda GRATIS onClick, onMouseEnter, type,
 * disabled, aria-*, etc. Encima añadimos props de diseño y overrides por instancia.
 */
export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant
  size?: ButtonSize
  fullWidth?: boolean
  loading?: boolean
  iconLeft?: ReactNode
  iconRight?: ReactNode
  // Overrides por instancia (pisan la variante/tamaño sin tocar tokens globales)
  bg?: string
  textColor?: string
  radius?: string
  padding?: string
  fontSize?: string
  // Lengua de Señas: URL del video/imagen de la seña para este botón.
  signSrc?: string
}
