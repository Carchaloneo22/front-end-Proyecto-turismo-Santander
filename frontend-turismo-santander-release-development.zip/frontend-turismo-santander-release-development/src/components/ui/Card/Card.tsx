import type { ReactNode } from 'react'
import { Heading } from '../Heading'
import { Text } from '../Text'
import { Link } from '../Link'
import { Badge } from '../Badge'
import styles from './Card.module.css'

export interface CardProps {
  image?: string
  imageAlt?: string
  badge?: string
  title: string
  description?: string
  linkLabel?: string
  signSrc?: string
  linkTo?: string
  children?: ReactNode
}

export function Card({
  image,
  imageAlt = '',
  badge,
  title,
  description,
  linkLabel,
  linkTo,
  signSrc,
  children,
}: CardProps) {
  return (
    <article className={styles.card}>
      {image && (
        <div className={styles.imageWrap}>
          <img src={image} alt={imageAlt} className={styles.image} loading="lazy" />
          {badge && <Badge className={styles.badge}>{badge}</Badge>}
        </div>
      )}
      <div className={styles.body}>
        <Heading level={3} signSrc={signSrc} size={4}>
          {title}
        </Heading>
        {description && (
          <Text size="sm" muted>
            {description}
          </Text>
        )}
        {children}
        {linkLabel && linkTo && (
          <Link to={linkTo} className={styles.link}>
            {linkLabel} →
          </Link>
        )}
      </div>
    </article>
  )
}
