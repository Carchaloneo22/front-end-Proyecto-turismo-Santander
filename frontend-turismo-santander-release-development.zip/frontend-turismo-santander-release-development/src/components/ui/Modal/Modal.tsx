import { useEffect, useRef, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import styles from './Modal.module.css'

interface ModalProps {
  isOpen: boolean
  onClose: () => void
  /** id del título interno → `aria-labelledby` (recomendado). */
  titleId?: string
  /** Alternativa a titleId cuando no hay un título visible. */
  ariaLabel?: string
  children: ReactNode
  className?: string
}

const FOCUSABLE =
  'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])'

/**
 * Modal — diálogo accesible reutilizable (WCAG 2.2). SRP: solo gestiona la
 * mecánica del diálogo; el contenido lo pone quien lo usa (OCP).
 * - `role="dialog"` + `aria-modal`, etiquetado por `titleId`/`ariaLabel`.
 * - Focus-trap con Tab/Shift+Tab, Esc para cerrar, clic en el fondo cierra.
 * - Devuelve el foco al elemento que lo abrió; bloquea el scroll del body.
 * - Se renderiza en un portal para escapar de overflow/stacking del árbol.
 */
export function Modal({
  isOpen,
  onClose,
  titleId,
  ariaLabel,
  children,
  className = '',
}: ModalProps) {
  const dialogRef = useRef<HTMLDivElement>(null)
  const prevFocus = useRef<HTMLElement | null>(null)

  useEffect(() => {
    if (!isOpen) return
    prevFocus.current = document.activeElement as HTMLElement
    const dialog = dialogRef.current

    const focusables = () =>
      dialog
        ? Array.from(dialog.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
            (el) => el.offsetParent !== null,
          )
        : []

    // Enfoca el primer control (o el propio diálogo) al abrir.
    ;(focusables()[0] ?? dialog)?.focus()

    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        onClose()
        return
      }
      if (e.key === 'Tab') {
        const items = focusables()
        if (items.length === 0) {
          e.preventDefault()
          return
        }
        const first = items[0]
        const last = items[items.length - 1]
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault()
          last.focus()
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault()
          first.focus()
        }
      }
    }

    document.addEventListener('keydown', onKey, true)
    return () => {
      document.removeEventListener('keydown', onKey, true)
      document.body.style.overflow = prevOverflow
      prevFocus.current?.focus?.()
    }
  }, [isOpen, onClose])

  if (!isOpen) return null

  return createPortal(
    <div
      className={styles.backdrop}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-label={ariaLabel}
        tabIndex={-1}
        className={`${styles.dialog} ${className}`}
      >
        <button type="button" className={styles.close} onClick={onClose} aria-label="Cerrar">
          ✕
        </button>
        {children}
      </div>
    </div>,
    document.body,
  )
}
