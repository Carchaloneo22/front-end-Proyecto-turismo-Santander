import { Heading } from '../Heading'
import { Text } from '../Text'
import styles from './SectionHeader.module.css'

interface SectionHeaderProps {
  title: string
  subtitle?: string
  align?: 'left' | 'center'
  signSrc?: string // Lengua de Señas: seña del título de la sección
}
export function SectionHeader({ title, subtitle, align = 'left', signSrc }: SectionHeaderProps) {
  return (
    <div className={`${styles.header} ${align === 'center' ? styles.center : ''}`}>
      <Heading level={2} size={2} signSrc={signSrc}>
        {title}
      </Heading>
      {subtitle && (
        <Text muted className={styles.subtitle}>
          {subtitle}
        </Text>
      )}
    </div>
  )
}
