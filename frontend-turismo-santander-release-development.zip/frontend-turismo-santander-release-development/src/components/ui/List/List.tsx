import type { ReactNode } from 'react'
import { useSignAttributes } from '../../../hooks/useSignAttributes'
import styles from './List.module.css'

interface ListProps {
  as?: 'ul' | 'ol'
  variant?: 'none' | 'disc' | 'decimal'
  className?: string
  signSrc?: string // Lengua de Señas: URL del video/imagen de la seña
  children: ReactNode
}

export function List({
  as: Tag = 'ul',
  variant = 'none',
  className = '',
  signSrc,
  children,
}: ListProps) {
  const sign = useSignAttributes(signSrc)
  return (
    <Tag className={`${styles.list} ${styles[variant]} ${className}`} {...sign}>
      {children}
    </Tag>
  )
}
