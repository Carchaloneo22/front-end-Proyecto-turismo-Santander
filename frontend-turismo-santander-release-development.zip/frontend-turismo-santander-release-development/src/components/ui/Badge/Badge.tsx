import type { HTMLAttributes, ReactNode } from 'react'
import { useSignAttributes } from '../../../hooks/useSignAttributes'
import styles from './Badge.module.css'

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: 'primary' | 'success' | 'neutral'
  signSrc?: string // Lengua de Señas: URL del video/imagen de la seña
  children: ReactNode
}

export function Badge({
  variant = 'primary',
  className = '',
  signSrc,
  children,
  ...rest
}: BadgeProps) {
  const label = typeof children === 'string' ? children : undefined
  const sign = useSignAttributes(signSrc, label)
  return (
    <span className={`${styles.badge} ${styles[variant]} ${className}`} {...sign} {...rest}>
      {children}
    </span>
  )
}
