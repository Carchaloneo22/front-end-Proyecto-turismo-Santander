import type { IconType } from 'react-icons'
import { useSignAttributes } from '../../../hooks/useSignAttributes'
import {
  FaFacebookF,
  FaInstagram,
  FaTiktok,
  FaWhatsapp,
  FaMoon,
  FaSun,
  FaUniversalAccess,
} from 'react-icons/fa6'

// Registro central: mapea un NOMBRE nuestro → el icono de la lib.
// Así el resto de la app usa <Icon name="facebook" /> y NO importa react-icons.
const ICONS = {
  facebook: FaFacebookF,
  instagram: FaInstagram,
  tiktok: FaTiktok,
  whatsapp: FaWhatsapp,
  moon: FaMoon,
  sun: FaSun,
  accessibility: FaUniversalAccess,
} satisfies Record<string, IconType>

export type IconName = keyof typeof ICONS

export interface IconProps {
  name: IconName
  size?: number | string
  color?: string
  className?: string
  title?: string
  signSrc?: string // Lengua de Señas: URL del video/imagen de la seña
}

export function Icon({ name, size = 18, color, className, title, signSrc }: IconProps) {
  const Cmp = ICONS[name]
  const sign = useSignAttributes(signSrc, title)
  const signable = !!sign['data-sign']
  return (
    <Cmp
      size={size}
      color={color}
      className={className}
      title={title}
      // Si es señable debe ser perceptible y enfocable → no ocultarlo a AT.
      aria-hidden={title || signable ? undefined : true}
      {...sign}
    />
  )
}
