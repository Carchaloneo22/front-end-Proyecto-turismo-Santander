import type { CSSProperties, HTMLAttributes, ReactNode } from 'react'
import { useSignAttributes } from '../../../hooks/useSignAttributes'
import styles from './Text.module.css'

/**
 * Etiquetas que puede tomar el texto. NO se usa `ElementType`: ese tipo incluye
 * también elementos vacíos (`<br>`, `<img>`, `<input>`), cuyas props declaran
 * `children?: undefined`; al intersecarlas con las del resto, TypeScript deducía
 * `children: never` y rechazaba cualquier hijo. Acotarlo a las etiquetas que de
 * verdad llevan texto lo resuelve y además documenta el átomo.
 */
type EtiquetaTexto =
  | 'p'
  | 'span'
  | 'div'
  | 'strong'
  | 'em'
  | 'small'
  | 'label'
  | 'li'
  | 'dt'
  | 'dd'
  | 'figcaption'
  | 'blockquote'
  | 'h1'
  | 'h2'
  | 'h3'
  | 'h4'
  | 'h5'
  | 'h6'

interface TextProps extends Omit<HTMLAttributes<HTMLElement>, 'color'> {
  as?: EtiquetaTexto
  size?: 'xs' | 'sm' | 'base' | 'lg' | 'xl'
  weight?: 'normal' | 'medium' | 'semibold' | 'bold'
  align?: 'left' | 'center' | 'right'
  color?: string
  muted?: boolean
  signSrc?: string
  children: ReactNode
}

export function Text({
  as: Tag = 'p',
  size = 'base',
  weight = 'normal',
  align,
  color,
  muted = false,
  signSrc,
  className = '',
  style,
  children,
  ...rest
}: TextProps) {
  const label = typeof children === 'string' ? children : undefined
  const sign = useSignAttributes(signSrc, label)

  const mergedStyle: CSSProperties = { color, textAlign: align, ...style }
  const classes = [styles.text, styles[size], styles[weight], muted ? styles.muted : '', className]
    .filter(Boolean)
    .join(' ')

  return (
    <Tag className={classes} style={mergedStyle} {...sign} {...rest}>
      {children}
    </Tag>
  )
}
