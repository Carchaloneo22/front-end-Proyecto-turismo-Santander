import type { CSSProperties, HTMLAttributes, ReactNode } from 'react'
import { useSignAttributes } from '../../../hooks/useSignAttributes'
import styles from './Heading.module.css'

type Level = 1 | 2 | 3 | 4 | 5 | 6

interface HeadingProps extends Omit<HTMLAttributes<HTMLHeadingElement>, 'color'> {
  level?: Level
  size?: Level
  align?: 'left' | 'center' | 'right'
  color?: string
  signSrc?: string
  children: ReactNode
}

export function Heading({
  level = 2,
  size,
  align,
  color,
  signSrc,
  className = '',
  style,
  children,
  ...rest
}: HeadingProps) {
  const label = typeof children === 'string' ? children : undefined
  const sign = useSignAttributes(signSrc, label)
  const Tag = `h${level}` as const
  const visual = size ?? level

  const mergedStyle: CSSProperties = { color, textAlign: align, ...style }
  const classes = `${styles.heading} ${styles[`s${visual}`]} ${className}`

  return (
    <Tag className={classes} style={mergedStyle} {...sign} {...rest}>
      {children}
    </Tag>
  )
}
