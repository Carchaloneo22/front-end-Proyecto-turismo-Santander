import { useState } from 'react'
import { useReducedMotion } from '../../../hooks/useReducedMotion'
import styles from './BanderaSantander.module.css'

/**
 * Id propio para el clipPath. NO se usa `useId()`: React genera identificadores
 * con caracteres especiales que rompen la referencia `url(#…)` del SVG, y el
 * relleno de color no llegaba a aplicarse. Un contador es estable y seguro.
 */
let contador = 0

interface BanderaSantanderProps {
  /** Alto en px (el ancho sale de la proporción 3:2). */
  size?: number
  /**
   * Texto accesible. Si se pasa → `role="img"` + `aria-label` (p. ej. "Cargando").
   * Si se omite → decorativa (`aria-hidden`), cuando el contenedor ya anuncia el estado.
   */
  label?: string
  className?: string
}

type Palette = { green: string; yellow: string; black: string; red: string; star: string }

// Bandera a color (sólida) y su versión "fantasma" en gris (estado sin llenar).
const COLOR: Palette = {
  green: '#1b8a3f',
  yellow: '#ffcf00',
  black: '#101418',
  red: '#d1141a',
  star: '#ffffff',
}
const GHOST: Palette = {
  green: '#e2e8f0',
  yellow: '#eceff3',
  black: '#cbd5e1',
  red: '#d8dee6',
  star: '#f1f5f9',
}

// Franjas horizontales (arriba→abajo): verde, amarillo, negro, amarillo, verde.
// Proporción real: verde:amarillo:negro = 3:1:1 (los verdes son ~3× los amarillos).
const BANDS: { y: number; h: number; key: keyof Palette }[] = [
  { y: 4, h: 19, key: 'green' },
  { y: 23, h: 6, key: 'yellow' },
  { y: 29, h: 6, key: 'black' },
  { y: 35, h: 6, key: 'yellow' },
  { y: 41, h: 19, key: 'green' },
]

// 7 estrellas blancas (las 7 provincias) sobre la franja roja vertical del asta.
const STAR_YS = [8, 15.5, 23, 30.5, 38, 45.5, 53]
const STAR_PATH =
  'M0,-1 L0.225,-0.309 0.951,-0.309 0.363,0.118 0.588,0.809 0,0.382 -0.588,0.809 -0.363,0.118 -0.951,-0.309 -0.225,-0.309 Z'

/** Dibuja la bandera sólida con la paleta dada (color o gris). */
function Flag({ p }: { p: Palette }) {
  return (
    <g>
      {BANDS.map((b) => (
        <rect key={b.y} x="4" y={b.y} width="88" height={b.h} fill={p[b.key]} />
      ))}
      <rect x="4" y="4" width="29" height="56" fill={p.red} />
      {STAR_YS.map((y) => (
        <path key={y} d={STAR_PATH} fill={p.star} transform={`translate(18.5 ${y}) scale(2.4)`} />
      ))}
    </g>
  )
}

/**
 * BanderaSantander — bandera del departamento de Santander (Colombia), sólida y
 * nítida. Como indicador de carga, se "llena de color" de abajo hacia arriba
 * sobre una versión gris (estado vacío), en bucle. Respeta `prefers-reduced-motion`:
 * sin animación, muestra la bandera a todo color.
 */
export function BanderaSantander({ size = 64, label, className = '' }: BanderaSantanderProps) {
  const reduce = useReducedMotion()
  const [clipId] = useState(() => `bandera-llenado-${(contador += 1)}`)

  const a11y = label
    ? { role: 'img' as const, 'aria-label': label }
    : { 'aria-hidden': true as const }

  return (
    <span
      className={`${styles.wrap} ${className}`}
      style={{ width: size * 1.5, height: size }}
      {...a11y}
    >
      <svg viewBox="0 0 96 64" width="100%" height="100%" className={styles.flag}>
        {reduce ? (
          // Sin movimiento: bandera sólida a todo color.
          <Flag p={COLOR} />
        ) : (
          <>
            <defs>
              {/* Rect que crece de abajo (y=60,h=0) hacia arriba (y=4,h=56). */}
              <clipPath id={clipId}>
                <rect x="0" width="96" y="4" height="56">
                  {/* Se llena en 0.6 s y se queda a todo color otros 0.8 s: antes
                      tardaba 1.2 s en subir y la bandera completa apenas se veía
                      un parpadeo antes de vaciarse otra vez. */}
                  <animate
                    attributeName="y"
                    dur="1.4s"
                    values="60;4;4"
                    keyTimes="0;0.43;1"
                    repeatCount="indefinite"
                  />
                  <animate
                    attributeName="height"
                    dur="1.4s"
                    values="0;56;56"
                    keyTimes="0;0.43;1"
                    repeatCount="indefinite"
                  />
                </rect>
              </clipPath>
            </defs>
            {/* Base gris (vacía) + color revelado por el relleno animado. */}
            <Flag p={GHOST} />
            <g clipPath={`url(#${clipId})`}>
              <Flag p={COLOR} />
            </g>
          </>
        )}
      </svg>
    </span>
  )
}
