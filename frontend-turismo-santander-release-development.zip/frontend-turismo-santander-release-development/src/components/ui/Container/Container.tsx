import type { CSSProperties, ReactNode } from 'react'
import { useSignAttributes } from '../../../hooks/useSignAttributes'
import styles from './Container.module.css'

/**
 * Etiquetas que puede tomar el contenedor. NO se usa `ElementType`: ese tipo
 * incluye también elementos vacíos (`<br>`, `<img>`, `<input>`), cuyas props
 * declaran `children?: undefined`; al intersecarlas con las del resto, TypeScript
 * deducía `children: never` y rechazaba cualquier hijo. Acotarlo a las etiquetas
 * que de verdad envuelven contenido lo resuelve y además documenta el átomo.
 */
type EtiquetaContenedor =
  | 'div'
  | 'section'
  | 'article'
  | 'main'
  | 'aside'
  | 'header'
  | 'footer'
  | 'nav'
  | 'ul'
  | 'ol'
  | 'li'
  | 'form'
  | 'figure'

interface ContainerProps {
  children: ReactNode
  as?: EtiquetaContenedor // <Container as="section"> para semántica
  maxWidth?: number | string // opcional: limita el ancho (boxed). Sin él = full-width.
  className?: string
  signSrc?: string // Lengua de Señas: URL del video/imagen de la seña
}

/**
 * Container — átomo de layout. Centraliza el ancho horizontal y el padding lateral
 * para que TODAS las zonas (navbar, footer, secciones) se alineen igual.
 * Por defecto es full-width con padding; con maxWidth se vuelve "boxed" centrado.
 */
export function Container({
  children,
  as: Tag = 'div',
  maxWidth,
  className = '',
  signSrc,
}: ContainerProps) {
  const style: CSSProperties | undefined = maxWidth
    ? { maxWidth: typeof maxWidth === 'number' ? `${maxWidth}px` : maxWidth }
    : undefined
  const sign = useSignAttributes(signSrc)

  return (
    <Tag className={`${styles.container} ${className}`} style={style} {...sign}>
      {children}
    </Tag>
  )
}
