import type { AnchorHTMLAttributes, ReactNode } from 'react'

export interface LinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  to: string // ruta interna (/transporte) o URL externa (https://...)
  external?: boolean // fuerza <a> normal; también se auto-detecta con http(s)
  signSrc?: string // Lengua de Señas: URL del video/imagen de la seña
  children: ReactNode
}
