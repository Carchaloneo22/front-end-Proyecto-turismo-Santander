import { Link as RouterLink } from 'react-router-dom'
import { useSignAttributes } from '../../../hooks/useSignAttributes'
import type { LinkProps } from './Link.types'

/**
 * Link — átomo de navegación. Envuelve react-router para que el resto de la app
 * NO dependa de la librería directamente (DIP). Cambiar de router = tocar SOLO aquí.
 * - Ruta interna → RouterLink (SPA, sin recargar la página).
 * - URL externa  → <a> normal con seguridad (noopener/noreferrer).
 */
export function Link({ to, external, signSrc, children, ...rest }: LinkProps) {
  const isExternal = external || /^https?:\/\//.test(to)
  const label = typeof children === 'string' ? children : undefined
  const sign = useSignAttributes(signSrc, label)

  if (isExternal) {
    return (
      <a href={to} target="_blank" rel="noopener noreferrer" {...sign} {...rest}>
        {children}
      </a>
    )
  }
  return (
    <RouterLink to={to} {...sign} {...rest}>
      {children}
    </RouterLink>
  )
}
