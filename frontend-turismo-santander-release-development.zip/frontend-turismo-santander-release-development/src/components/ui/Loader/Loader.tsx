import { BanderaSantander } from '../BanderaSantander'
import styles from './Loader.module.css'

interface LoaderProps {
  /** Progreso 0..100. Si se omite, muestra solo el texto sin porcentaje. */
  progress?: number
  label?: string
  /** Cubre toda la pantalla (overlay) o solo su contenedor. */
  fullscreen?: boolean
}

/**
 * Loader — pantalla de carga de marca: la bandera de Santander llenándose de
 * color + progreso. Reutilizable (páginas, secciones). Accesible: `role="status"`
 * + `aria-live` anuncian el progreso; la bandera lleva su `aria-label`.
 */
export function Loader({ progress, label = 'Cargando', fullscreen = true }: LoaderProps) {
  return (
    <div
      className={`${styles.loader} ${fullscreen ? styles.fullscreen : ''}`}
      role="status"
      aria-live="polite"
    >
      <BanderaSantander size={96} label={label} />
      <p className={styles.text}>
        {label}
        {typeof progress === 'number' ? ` ${progress}%` : '…'}
      </p>
      {typeof progress === 'number' && (
        <span className={styles.bar} aria-hidden="true">
          <span className={styles.barFill} style={{ width: `${progress}%` }} />
        </span>
      )}
    </div>
  )
}
