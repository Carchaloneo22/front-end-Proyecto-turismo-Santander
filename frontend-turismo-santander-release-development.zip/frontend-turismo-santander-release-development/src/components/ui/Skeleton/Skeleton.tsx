import styles from './Skeleton.module.css'

interface SkeletonProps {
  /** Alto en px. */
  h?: number
  /** Ancho (px o %). */
  w?: number | string
  /** Radio de borde en px. */
  r?: number
  className?: string
}

/** Bloque de carga con efecto shimmer. Decorativo (`aria-hidden`). */
export function Skeleton({ h = 16, w = '100%', r = 6, className = '' }: SkeletonProps) {
  return (
    <span
      className={`${styles.sk} ${className}`}
      style={{ height: h, width: w, borderRadius: r }}
      aria-hidden="true"
    />
  )
}

/** Esqueleto de una tarjeta de experiencia (imagen + líneas de texto). */
export function SkeletonCard() {
  return (
    <div className={styles.card} aria-hidden="true">
      <Skeleton h={170} r={12} />
      <Skeleton h={12} w="45%" />
      <Skeleton h={20} w="85%" />
      <Skeleton h={12} w="100%" />
      <Skeleton h={12} w="65%" />
    </div>
  )
}
