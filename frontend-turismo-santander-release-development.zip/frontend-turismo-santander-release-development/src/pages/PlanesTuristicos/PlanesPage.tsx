import { useCallback } from 'react'
import { CatalogoPage } from '../../components/sections/CatalogoPage'
import type { CardProps } from '../../components/ui/Card'
import { useListado } from '../../hooks/useListado'
import { planesService, type Plan } from '../../services'
import { imagenUrl } from '../../lib/gcs'
import { precio } from '../../lib/formato'

const BANNER = 'https://picsum.photos/seed/banner-planes/1600/600'

function planToCard(plan: Plan): CardProps {
  return {
    image: imagenUrl(plan.img_url),
    imageAlt: `Plan turístico: ${plan.nombre}`,
    // El badge lleva lo que decide una compra: cuánto cuesta y cuánto dura.
    badge: `${precio(plan.precio)} · ${plan.duracion}`,
    title: plan.nombre,
    description: plan.descripcion ?? plan.incluye,
  }
}

export function PlanesPage() {
  // useCallback: `useListado` lo tiene como dependencia de su efecto, así que una
  // función nueva en cada render lo dispararía sin parar.
  const cargar = useCallback(() => planesService.listarPublico(), [])
  const { datos, cargando, error } = useListado<Plan>(
    cargar,
    'No pudimos cargar los planes turísticos. Inténtalo de nuevo en un momento.',
  )

  return (
    <CatalogoPage
      seo={{
        title: 'Planes turísticos accesibles en Santander — Santander Accesible',
        description:
          'Planes turísticos por Santander con accesibilidad real para personas con discapacidad visual, auditiva y motriz.',
      }}
      hero={{
        eyebrow: 'Planes turísticos',
        title: 'Viaja por Santander sin barreras',
        subtitle:
          'Planes armados con accesibilidad real: transporte adaptado, guianza en lengua de señas y alojamientos verificados.',
        banner: BANNER,
      }}
      grid={{
        title: 'Planes disponibles',
        subtitle: 'Cada plan indica su accesibilidad, duración y qué incluye.',
        loadingLabel: 'Cargando planes…',
        emptyLabel: 'Todavía no hay planes publicados. Vuelve pronto.',
      }}
      items={datos.map(planToCard)}
      cargando={cargando}
      error={error}
      etiquetaCarga="Cargando planes"
    />
  )
}
