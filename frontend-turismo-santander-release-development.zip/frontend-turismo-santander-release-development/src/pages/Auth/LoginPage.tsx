import { useEffect, useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { Link } from '../../components/ui/Link'
import { Campo } from './Campo'
import { guardarSesion } from '../../lib/sesionDemo'
import logo from '../../assets/logo.webp'
import styles from './Auth.module.css'

export function LoginPage() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [errores, setErrores] = useState<{ email?: string; password?: string }>({})

  useEffect(() => {
    const previo = document.title
    document.title = 'Iniciar sesión — Santander Accesible'
    return () => {
      document.title = previo
    }
  }, [])

  const enviar = (e: FormEvent) => {
    e.preventDefault()
    const errs: typeof errores = {}
    if (!/^\S+@\S+\.\S+$/.test(email)) errs.email = 'Ingresa un correo electrónico válido.'
    if (password.length < 6) errs.password = 'La contraseña debe tener al menos 6 caracteres.'
    setErrores(errs)
    if (Object.keys(errs).length > 0) return
    // Demo de presentación: guarda sesión local y entra al panel. Reemplazar por
    // `useAuthStore.login` cuando el backend de autenticación esté conectado.
    guardarSesion({ nombre: email.split('@')[0], email })
    navigate('/dashboard')
  }

  return (
    <div className={styles.wrap}>
      <form className={styles.card} onSubmit={enviar} noValidate>
        <div className={styles.marca}>
          <img src={logo} alt="" className={styles.logo} />
          <span>Santander Accesible</span>
        </div>
        <h1 className={styles.titulo}>Iniciar sesión</h1>
        <p className={styles.sub}>Entra para gestionar tus reservas y favoritos.</p>

        <Campo
          id="email"
          label="Correo electrónico"
          type="email"
          autoComplete="email"
          placeholder="tucorreo@ejemplo.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          error={errores.email}
        />
        <Campo
          id="password"
          label="Contraseña"
          type="password"
          autoComplete="current-password"
          placeholder="••••••••"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={errores.password}
        />

        <div className={styles.entreLinea}>
          <Link to="/recuperar-contrasena" className={styles.linkPeq}>
            ¿Olvidaste tu contraseña?
          </Link>
        </div>

        <button type="submit" className={styles.btn}>
          Entrar
        </button>

        <p className={styles.pie}>
          ¿No tienes cuenta? <Link to="/registro">Regístrate</Link>
        </p>
        <p className={styles.demo}>Demo de presentación: cualquier correo válido entra al panel.</p>
        <p className={styles.volver}>
          <Link to="/">← Volver al inicio</Link>
        </p>
      </form>
    </div>
  )
}
