import { useEffect, useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { Link } from '../../components/ui/Link'
import { Campo } from './Campo'
import { guardarSesion } from '../../lib/sesionDemo'
import logo from '../../assets/logo.webp'
import styles from './Auth.module.css'

interface Errores {
  nombre?: string
  email?: string
  password?: string
  confirmar?: string
  acepta?: string
}

export function RegistroPage() {
  const navigate = useNavigate()
  const [nombre, setNombre] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmar, setConfirmar] = useState('')
  const [acepta, setAcepta] = useState(false)
  const [errores, setErrores] = useState<Errores>({})

  useEffect(() => {
    const previo = document.title
    document.title = 'Crear cuenta — Santander Accesible'
    return () => {
      document.title = previo
    }
  }, [])

  const enviar = (e: FormEvent) => {
    e.preventDefault()
    const errs: Errores = {}
    if (nombre.trim().length < 3) errs.nombre = 'Ingresa tu nombre completo.'
    if (!/^\S+@\S+\.\S+$/.test(email)) errs.email = 'Ingresa un correo electrónico válido.'
    if (password.length < 6) errs.password = 'Mínimo 6 caracteres.'
    if (confirmar !== password) errs.confirmar = 'Las contraseñas no coinciden.'
    if (!acepta) errs.acepta = 'Debes aceptar las políticas para continuar.'
    setErrores(errs)
    if (Object.keys(errs).length > 0) return
    // Demo de presentación (ver LoginPage).
    guardarSesion({ nombre: nombre.trim(), email })
    navigate('/dashboard')
  }

  return (
    <div className={styles.wrap}>
      <form className={styles.card} onSubmit={enviar} noValidate>
        <div className={styles.marca}>
          <img src={logo} alt="" className={styles.logo} />
          <span>Santander Accesible</span>
        </div>
        <h1 className={styles.titulo}>Crear cuenta</h1>
        <p className={styles.sub}>Regístrate para guardar tus planes accesibles favoritos.</p>

        <Campo
          id="nombre"
          label="Nombre completo"
          autoComplete="name"
          placeholder="Ej: María Gómez"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
          error={errores.nombre}
        />
        <Campo
          id="email"
          label="Correo electrónico"
          type="email"
          autoComplete="email"
          placeholder="tucorreo@ejemplo.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          error={errores.email}
        />
        <Campo
          id="password"
          label="Contraseña"
          type="password"
          autoComplete="new-password"
          placeholder="Mínimo 6 caracteres"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={errores.password}
        />
        <Campo
          id="confirmar"
          label="Confirmar contraseña"
          type="password"
          autoComplete="new-password"
          placeholder="Repite la contraseña"
          value={confirmar}
          onChange={(e) => setConfirmar(e.target.value)}
          error={errores.confirmar}
        />

        <label className={styles.check}>
          <input type="checkbox" checked={acepta} onChange={(e) => setAcepta(e.target.checked)} />
          <span>
            Acepto la <Link to="/politica-de-datos">Política de Tratamiento de Datos</Link> y la{' '}
            <Link to="/politica-de-cookies">Política de Cookies</Link>.
          </span>
        </label>
        {errores.acepta && (
          <span className={styles.error} role="alert">
            {errores.acepta}
          </span>
        )}

        <button type="submit" className={styles.btn}>
          Crear cuenta
        </button>

        <p className={styles.pie}>
          ¿Ya tienes cuenta? <Link to="/login">Inicia sesión</Link>
        </p>
        <p className={styles.volver}>
          <Link to="/">← Volver al inicio</Link>
        </p>
      </form>
    </div>
  )
}
