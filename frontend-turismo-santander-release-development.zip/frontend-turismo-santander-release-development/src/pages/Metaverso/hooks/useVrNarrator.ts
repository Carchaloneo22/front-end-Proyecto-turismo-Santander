import { useCallback, useEffect, useRef } from 'react'
import { speak, stopSpeaking } from '../../../lib/speak'
import type { SitioTuristico } from '../../../features/destinos'

/**
 * useVrNarrator — audio-descripción de la experiencia VR (regla de accesibilidad).
 * Reutiliza `lib/speak.ts` (Web Speech API). SRP: encapsula QUÉ y CUÁNDO narrar,
 * evitando lógica repartida por el componente.
 *
 * - `narratePlace`: al entrar a un lugar → nombre + descripción. La evidencia en
 *   turismo virtual señala la narración como el mayor factor de presencia
 *   (presencia espacial 0.82 con narración vs 0.43 sin ella), así que va
 *   activada por defecto: no es solo accesibilidad, es la experiencia.
 * - `narrateHotspot`: al apuntar/seleccionar un hotspot → su etiqueta (sin repetir
 *   mientras se mantiene el foco en el mismo).
 * - Todo se silencia si `enabled` es false (toggle de audio-descripción).
 */
export function useVrNarrator(enabled: boolean) {
  const lastHotspot = useRef<string | null>(null)

  const narratePlace = useCallback(
    (sitio: SitioTuristico) => {
      if (!enabled) return
      speak(`${sitio.nombre}. ${sitio.descripcion}`)
    },
    [enabled],
  )

  const narrateHotspot = useCallback(
    (label: string) => {
      if (!enabled) return
      if (lastHotspot.current === label) return // evita repetir mientras se apunta
      lastHotspot.current = label
      speak(label)
    },
    [enabled],
  )

  const resetHotspot = useCallback(() => {
    lastHotspot.current = null
  }, [])

  /**
   * Narra un texto cualquiera, siempre (sin la deduplicación de `narrateHotspot`,
   * que existía para no repetir mientras se apunta). Se usa en momentos con
   * sentido: al presentar la ficha de un lugar antes de viajar.
   */
  const narrar = useCallback(
    (texto: string) => {
      if (!enabled) return
      speak(texto)
    },
    [enabled],
  )

  /**
   * Corta la locución en curso. Se llama al cerrar una ficha: si no, la voz
   * seguía contando un lugar que el visitante ya había cerrado, y solo paraba al
   * abrir otro.
   */
  const callar = useCallback(() => {
    stopSpeaking()
  }, [])

  // Al apagar la audio-descripción o desmontar, corta cualquier locución en curso.
  useEffect(() => {
    if (!enabled) stopSpeaking()
    return () => stopSpeaking()
  }, [enabled])

  return { narratePlace, narrateHotspot, resetHotspot, narrar, callar }
}
