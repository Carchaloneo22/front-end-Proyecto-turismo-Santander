import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Link } from '../../components/ui/Link'
import { leerSesion, cerrarSesion, type SesionDemo } from '../../lib/sesionDemo'
import logo from '../../assets/logo.webp'
import styles from './DashboardPage.module.css'

const TARJETAS = [
  {
    icono: '📋',
    titulo: 'Mis reservas',
    texto: 'Aún no tienes reservas. Explora planes accesibles y reserva tu próxima experiencia.',
    cta: 'Ver planes',
    to: '/planes-turisticos',
  },
  {
    icono: '❤️',
    titulo: 'Favoritos',
    texto: 'Guarda hospedajes, rutas y artesanías para encontrarlos rápido.',
    cta: 'Explorar',
    to: '/hospedaje',
  },
  {
    icono: '🗺️',
    titulo: 'Destinos',
    texto: 'Descubre los municipios accesibles de Santander y sus sitios.',
    cta: 'Ver mapa',
    to: '/',
  },
  {
    icono: '🥽',
    titulo: 'Experiencias 360°',
    texto: 'Recorre los destinos en realidad virtual antes de viajar.',
    cta: 'Abrir metaverso',
    to: '/metaverso',
  },
]

export function DashboardPage() {
  const navigate = useNavigate()
  const [sesion, setSesion] = useState<SesionDemo | null>(() => leerSesion())

  useEffect(() => {
    const previo = document.title
    document.title = 'Panel — Santander Accesible'
    return () => {
      document.title = previo
    }
  }, [])

  // Sin sesión demo → al login (no es autenticación real; solo el flujo de la demo).
  useEffect(() => {
    if (!leerSesion()) navigate('/login', { replace: true })
  }, [navigate])

  const salir = () => {
    cerrarSesion()
    setSesion(null)
    navigate('/')
  }

  const nombre = sesion?.nombre ?? 'invitado'

  return (
    <div className={styles.wrap}>
      <header className={styles.topbar}>
        <Link to="/" className={styles.marca}>
          <img src={logo} alt="" className={styles.logo} />
          <span>Santander Accesible</span>
        </Link>
        <button type="button" className={styles.salir} onClick={salir}>
          Cerrar sesión
        </button>
      </header>

      <main className={styles.main}>
        <h1 className={styles.saludo}>Hola, {nombre} 👋</h1>
        <p className={styles.saludoSub}>
          Bienvenido a tu panel. Este es un espacio de demostración.
        </p>

        <section className={styles.stats} aria-label="Resumen">
          <div className={styles.stat}>
            <span className={styles.statNum}>0</span>
            <span className={styles.statLbl}>Reservas activas</span>
          </div>
          <div className={styles.stat}>
            <span className={styles.statNum}>0</span>
            <span className={styles.statLbl}>Favoritos</span>
          </div>
          <div className={styles.stat}>
            <span className={styles.statNum}>4</span>
            <span className={styles.statLbl}>Municipios accesibles</span>
          </div>
        </section>

        <div className={styles.grid}>
          {TARJETAS.map((t) => (
            <article key={t.titulo} className={styles.card}>
              <span className={styles.cardIcono} aria-hidden="true">
                {t.icono}
              </span>
              <h2 className={styles.cardTitulo}>{t.titulo}</h2>
              <p className={styles.cardText}>{t.texto}</p>
              <Link to={t.to} className={styles.cardCta}>
                {t.cta} →
              </Link>
            </article>
          ))}
        </div>
      </main>
    </div>
  )
}
