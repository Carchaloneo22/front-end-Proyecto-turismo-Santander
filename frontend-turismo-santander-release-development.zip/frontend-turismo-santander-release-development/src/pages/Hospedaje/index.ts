export { HospePage } from './HospePage'
