export { PoliticaCookiesPage } from './PoliticaCookiesPage'
export { PoliticaDatosPage } from './PoliticaDatosPage'
export { TerminosPage } from './TerminosPage'
