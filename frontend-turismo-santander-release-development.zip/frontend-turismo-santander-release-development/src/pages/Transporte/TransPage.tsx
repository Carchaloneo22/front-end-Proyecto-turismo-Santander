import { useCallback } from 'react'
import { CatalogoPage } from '../../components/sections/CatalogoPage'
import type { CardProps } from '../../components/ui/Card'
import { useListado } from '../../hooks/useListado'
import { transporteService, type Ruta } from '../../services'
import { imagenUrl } from '../../lib/gcs'
import { precio, fechaHora } from '../../lib/formato'

const BANNER = 'https://picsum.photos/seed/banner-transporte/1600/600'

function rutaToCard(r: Ruta): CardProps {
  return {
    image: imagenUrl(r.img_url),
    imageAlt: `Ruta de ${r.origen} a ${r.destino}`,
    badge: precio(r.precio),
    title: `${r.origen} → ${r.destino}`,
    description: [fechaHora(r.fecha_salida, r.hora_salida), r.empresa, r.descripcion]
      .filter(Boolean)
      .join(' · '),
  }
}

export function TransPage() {
  const cargar = useCallback(() => transporteService.listarPublico(), [])
  const { datos, cargando, error } = useListado<Ruta>(
    cargar,
    'No pudimos cargar las rutas de transporte. Inténtalo de nuevo en un momento.',
  )

  return (
    <CatalogoPage
      seo={{
        title: 'Transporte adaptado en Santander — Santander Accesible',
        description:
          'Rutas de transporte por Santander con vehículos adaptados para personas con movilidad reducida.',
      }}
      hero={{
        eyebrow: 'Transporte',
        title: 'Llegar no debería ser la parte difícil',
        subtitle:
          'Rutas por Santander en vehículos adaptados, con horarios y precios claros desde el principio.',
        banner: BANNER,
      }}
      grid={{
        title: 'Rutas disponibles',
        subtitle: 'Salidas programadas con su fecha, hora y empresa operadora.',
        loadingLabel: 'Cargando rutas…',
        emptyLabel: 'Todavía no hay rutas publicadas. Vuelve pronto.',
      }}
      items={datos.map(rutaToCard)}
      cargando={cargando}
      error={error}
      etiquetaCarga="Cargando rutas"
    />
  )
}
