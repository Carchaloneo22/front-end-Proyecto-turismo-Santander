// src/services/DestinosService.ts
/**
 * DestinosService — Destinos promocionados en el Home.
 * Estos NO son planes turísticos. Son las ciudades destacadas de Santander.
 */
import { HttpServiceBase } from './base/HttpServiceBase'
import { conRespaldo, MODO_PLACEHOLDER } from './base/conRespaldo'
import { detallePlaceholder } from './detallePlaceholder'
import type { DestinoDto } from '../features/destinos/destinos.api'

export interface Destino {
  id: number
  id_ciudad: string
  ciudad: string
  titulo: string
  /**
   * Segmento de /destinos/:slug. Viene de la base y no se recalcula aquí: el
   * backend lo deriva con slugArchivo() y el front lo hacía con slugDe(), dos
   * funciones que tenían que dar lo mismo y ya divergieron una vez ('Parque San
   * Pío' → 'parque-san-p-io' en PHP, 'parque-san-pio' en JS).
   */
  slug: string
  descripcion: string
  img_url: string | null
  sign_url: string | null
  badge: string | null
  orden: number
  activo: boolean
}

export interface DestinoPayload {
  id?: number
  titulo: string
  descripcion: string
  id_ciudad: string
  img_url?: string | null
  sign_url?: string | null
  badge?: string | null
  orden?: number
  activo?: boolean
}

class DestinosService extends HttpServiceBase {
  /** Lista destinos activos para el Home (modo presentación: JSON local). */
  async listar(): Promise<Destino[]> {
    return conRespaldo(() => this.get<Destino[]>('/destinos/listar.php'), '/data/destinos.json')
  }

  /** Lista todos (panel admin, incluye inactivos). */
  async listarAdmin(): Promise<Destino[]> {
    return this.get<Destino[]>('/destinos/listar.php', { todos: 1 })
  }

  /**
   * Un municipio con todos sus sitios, para /destinos/:slug.
   *
   * Sin respaldo estático a propósito, al revés que listar(): el Home tiene que
   * pintar algo aunque la API esté caída, pero aquí un respaldo enseñaría un
   * municipio con datos viejos —o los de otro— haciéndolos pasar por buenos. Si
   * falla, la página lo dice.
   */
  async detalle(slug: string): Promise<DestinoDto> {
    if (MODO_PLACEHOLDER) return detallePlaceholder(slug)
    return this.get<DestinoDto>('/destinos/detalle.php', { ciudad: slug })
  }

  /** Crea o actualiza un destino (solo admin). */
  async guardar(payload: DestinoPayload): Promise<{ id: number; mensaje: string }> {
    return this.post('/destinos/crear.php', payload)
  }

  /** Elimina un destino (soft delete, solo admin). */
  async eliminar(id: number): Promise<void> {
    await this.post('/destinos/eliminar.php', { id })
  }
}

export const destinosService = new DestinosService()
