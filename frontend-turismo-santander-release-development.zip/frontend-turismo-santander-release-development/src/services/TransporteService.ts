// src/services/TransporteService.ts
/**
 * TransporteService — CRUD de rutas de transporte.
 */
import { HttpServiceBase } from './base/HttpServiceBase'
import { conRespaldo } from './base/conRespaldo'

export interface Ruta {
  id: number
  origen: string
  destino: string
  fecha_salida: string
  hora_salida: string
  precio: number
  descripcion: string | null
  disponible: boolean
  img_url: string | null
  empresa?: string
  id_empresa?: number
}

export interface RutaPayload {
  id?: number
  origen: string
  destino: string
  fecha_salida: string
  hora_salida: string
  precio: number
  descripcion?: string
  disponible?: boolean
  img_url?: string | null
}

/**
 * Alias de tipo y NO interface, a propósito: `get()` recibe un
 * `Record<string, unknown>`, y TypeScript solo da índice implícito a los alias
 * —una interface puede fusionarse con declaraciones futuras, así que nunca lo
 * asume—. Con interface había que forzar un cast que ocultaba el motivo.
 */
export type BusquedaTransporte = {
  origen: string
  destino: string
  fecha?: string
}

class TransporteService extends HttpServiceBase {
  /** Lista rutas públicas (disponibles). */
  async listarPublico(): Promise<Ruta[]> {
    return conRespaldo(() => this.get<Ruta[]>('/transporte/listar.php'), '/data/transporte.json')
  }

  /** Lista rutas de la empresa en sesión (panel). */
  async listarPanel(): Promise<Ruta[]> {
    return this.get<Ruta[]>('/transporte/listar.php', { panel: 1 })
  }

  /** Busca rutas por origen/destino/fecha. */
  async buscar(params: BusquedaTransporte): Promise<Ruta[]> {
    return this.get<Ruta[]>('/transporte/buscar.php', params)
  }

  /** Crea o actualiza una ruta. */
  async guardar(payload: RutaPayload): Promise<{ id: number; mensaje: string }> {
    return this.post('/transporte/crear.php', payload)
  }

  /** Elimina una ruta por ID. */
  async eliminar(id: number): Promise<{ mensaje: string }> {
    return this.post('/transporte/eliminar.php', { id })
  }
}

export const transporteService = new TransporteService()
