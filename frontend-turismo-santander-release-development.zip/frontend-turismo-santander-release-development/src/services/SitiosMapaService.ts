import { HttpServiceBase } from './base/HttpServiceBase'
import { conRespaldo } from './base/conRespaldo'
import type { ModalidadId } from '../features/experiencias/modalidades'
import type { TipoLugar } from '../features/experiencias/tiposLugar'

/** Un punto del mapa: sitio turístico o lugar de interés. */
export interface SitioMapa {
  id: number
  nombre: string
  tipo: TipoLugar
  modalidad: ModalidadId
  municipio: string
  descripcion: string
  lat: number
  lng: number
  img_url: string
}

class SitiosMapaService extends HttpServiceBase {
  /** Sitios y lugares de interés para el mapa (modo presentación: JSON). */
  async listar(): Promise<SitioMapa[]> {
    return conRespaldo(() => this.get<SitioMapa[]>('/sitios/mapa.php'), '/data/sitios-mapa.json')
  }
}

export const sitiosMapaService = new SitiosMapaService()
