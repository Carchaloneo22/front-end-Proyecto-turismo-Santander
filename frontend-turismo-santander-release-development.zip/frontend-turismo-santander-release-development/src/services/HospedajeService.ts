// src/services/HospedajeService.ts
/**
 * HospedajeService — CRUD de hospedajes.
 */
import { HttpServiceBase } from './base/HttpServiceBase'
import { conRespaldo } from './base/conRespaldo'

export interface ServicioHospedaje {
  id: number
  nombre: string
}

export interface Hospedaje {
  id: number
  nombre: string
  tipo: string
  id_ciudad: string
  ciudad: string
  descripcion: string | null
  precio_noche: number
  accesibilidad: string
  capacidad_max: number
  disponible: boolean
  img_url: string | null
  servicios: ServicioHospedaje[]
  servicios_txt: string
  empresa?: string
  id_empresa?: number
  fecha_creacion?: string
}

export interface HospedajePayload {
  id?: number
  nombre: string
  tipo: string
  id_ciudad: string
  descripcion?: string
  precio_noche: number
  accesibilidad: string
  capacidad_max: number
  disponible?: boolean
  img_url?: string | null
  servicios_ids: number[]
}

class HospedajeService extends HttpServiceBase {
  /** Lista hospedajes públicos (disponibles). */
  async listarPublico(): Promise<Hospedaje[]> {
    return conRespaldo(() => this.get<Hospedaje[]>('/hospedaje/listar.php'), '/data/hospedaje.json')
  }

  /** Lista hospedajes de la empresa en sesión (panel). */
  async listarPanel(): Promise<Hospedaje[]> {
    return this.get<Hospedaje[]>('/hospedaje/listar.php', { panel: 1 })
  }

  /** Crea o actualiza un hospedaje. */
  async guardar(payload: HospedajePayload): Promise<{ id: number; mensaje: string }> {
    return this.post('/hospedaje/crear.php', payload)
  }

  /** Elimina un hospedaje por ID. */
  async eliminar(id: number): Promise<{ mensaje: string }> {
    return this.post('/hospedaje/eliminar.php', { id })
  }

  /** Lista los servicios disponibles (WiFi, Piscina, etc). */
  async listarServicios(): Promise<ServicioHospedaje[]> {
    return this.get<ServicioHospedaje[]>('/hospedaje/servicios_hospedaje.php')
  }
}

export const hospedajeService = new HospedajeService()
