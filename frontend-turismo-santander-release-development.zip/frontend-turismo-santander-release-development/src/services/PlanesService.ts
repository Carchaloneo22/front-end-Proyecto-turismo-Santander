// src/services/PlanesService.ts
/**
 * PlanesService — CRUD de planes turísticos.
 * Extiende HttpServiceBase → hereda reintentos, debugger y sobre {ok, data}.
 */
import { HttpServiceBase } from './base/HttpServiceBase'
import { conRespaldo } from './base/conRespaldo'

export interface Plan {
  id: number
  nombre: string
  duracion: string
  descripcion: string | null
  incluye: string
  id_tipo_plan: number
  tipo_plan: string
  precio: number
  accesibilidad: string
  disponible: boolean
  id_ciudad: string
  ciudad: string
  img_url: string | null
  empresa?: string
  id_empresa?: number
  fecha_creacion?: string
}

export interface PlanPayload {
  id?: number
  nombre: string
  duracion: string
  descripcion?: string
  incluye: string
  id_tipo_plan: number
  precio: number
  accesibilidad: string
  id_ciudad: string
  disponible?: boolean
  img_url?: string | null
}

class PlanesService extends HttpServiceBase {
  /** Lista planes públicos (disponibles). */
  async listarPublico(): Promise<Plan[]> {
    return conRespaldo(() => this.get<Plan[]>('/planes/listar.php'), '/data/planes.json')
  }

  /** Lista planes de la empresa en sesión (panel). */
  async listarPanel(): Promise<Plan[]> {
    return this.get<Plan[]>('/planes/listar.php', { panel: 1 })
  }

  /** Crea o actualiza un plan turístico. */
  async guardar(payload: PlanPayload): Promise<{ id: number; mensaje: string }> {
    return this.post('/planes/crear.php', payload)
  }

  /** Elimina un plan por ID. */
  async eliminar(id: number): Promise<{ mensaje: string }> {
    return this.post('/planes/eliminar.php', { id })
  }
}

export const planesService = new PlanesService()
