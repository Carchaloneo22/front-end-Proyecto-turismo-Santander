import { HttpServiceBase } from './base/HttpServiceBase'
import { conRespaldo } from './base/conRespaldo'
import type { ModalidadId } from '../features/experiencias/modalidades'

/** Una experiencia/sitio turístico clasificado por modalidad de turismo. */
export interface Experiencia {
  id: number
  nombre: string
  modalidad: ModalidadId
  municipio: string
  descripcion: string
  img_url: string
}

class ExperienciasService extends HttpServiceBase {
  /** Catálogo de experiencias organizado por modalidad (modo presentación: JSON). */
  async listar(): Promise<Experiencia[]> {
    return conRespaldo(
      () => this.get<Experiencia[]>('/experiencias/listar.php'),
      '/data/experiencias.json',
    )
  }
}

export const experienciasService = new ExperienciasService()
